#!/bin/bash

# Simple fix for the NGINX domain configuration issue
# This script only modifies what's necessary to fix the rtmp_stat directive error

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    print_message "This script must be run as root. Try using sudo." "$red"
    exit 1
fi

# Domain name
DOMAIN="hwosecurity.org"

print_message "Simple NGINX Config Fix for $DOMAIN" "$blue"
print_message "=================================" "$blue"
echo ""

# Backup current configurations
print_message "Creating backup of current configurations..." "$yellow"
if [ -f "/etc/nginx/sites-available/$DOMAIN.conf" ]; then
    cp "/etc/nginx/sites-available/$DOMAIN.conf" "/etc/nginx/sites-available/$DOMAIN.conf.backup.$(date +%s)"
    print_message "Domain config backed up" "$green"
fi

if [ -f "/etc/nginx/nginx.conf" ]; then
    cp "/etc/nginx/nginx.conf" "/etc/nginx/nginx.conf.backup.$(date +%s)"
    print_message "Main NGINX config backed up" "$green"
fi

# Check for the problematic rtmp_stat directive
if grep -q "rtmp_stat all" "/etc/nginx/sites-available/$DOMAIN.conf" 2>/dev/null; then
    print_message "Found problematic rtmp_stat directive. Fixing..." "$yellow"
    
    # Replace the rtmp_stat directive with a simple HTTP location
    sed -i 's/rtmp_stat all;/# Stats displayed using HTTP\n        root \/var\/www\/stream;/g' "/etc/nginx/sites-available/$DOMAIN.conf"
    sed -i 's/rtmp_stat_stylesheet stat.xsl;//g' "/etc/nginx/sites-available/$DOMAIN.conf"
    
    print_message "Fixed rtmp_stat directive in domain configuration" "$green"
else
    print_message "No problematic rtmp_stat directive found in domain config" "$green"
fi

# Create stream directories if they don't exist
if [ ! -d "/var/www/stream/hls" ] || [ ! -d "/var/www/stream/dash" ]; then
    print_message "Creating stream directories..." "$yellow"
    mkdir -p /var/www/stream/hls
    mkdir -p /var/www/stream/dash
    chmod 755 -R /var/www/stream
    chown -R www-data:www-data /var/www/stream
    print_message "Stream directories created and permissions set" "$green"
fi

# Test NGINX configuration
print_message "Testing NGINX configuration..." "$yellow"
if nginx -t; then
    print_message "NGINX configuration is valid!" "$green"
    
    # Reload NGINX to apply changes
    print_message "Reloading NGINX..." "$yellow"
    systemctl reload nginx
    
    print_message "Fix completed successfully!" "$green"
else
    print_message "NGINX configuration test failed." "$red"
    print_message "The problem might be more complex. Try running ./diagnose.sh for more detailed diagnostics." "$yellow"
    exit 1
fi