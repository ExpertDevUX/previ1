#!/bin/bash

# Diagnostic script for NGINX and domain configuration
# This script checks for common issues and helps diagnose domain-related problems

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

print_message "NGINX and Domain Configuration Diagnostic" "$blue"
print_message "=======================================" "$blue"
echo ""

# Domain name to check
DOMAIN=${1:-"hwosecurity.org"}
print_message "Checking domain: $DOMAIN" "$yellow"
echo ""

# 1. Check if NGINX is installed
print_message "Checking if NGINX is installed..." "$yellow"
if command -v nginx &> /dev/null; then
    print_message "NGINX is installed: $(nginx -v 2>&1)" "$green"
else
    print_message "NGINX is not installed!" "$red"
    print_message "Please install NGINX first with: sudo apt-get install nginx" "$yellow"
    exit 1
fi
echo ""

# 2. Check NGINX configuration syntax
print_message "Checking NGINX configuration syntax..." "$yellow"
if nginx -t &> /tmp/nginx_config_test; then
    print_message "NGINX configuration syntax is valid" "$green"
else
    print_message "NGINX configuration has errors:" "$red"
    cat /tmp/nginx_config_test
    echo ""
fi
echo ""

# 3. Check if the domain configuration exists
print_message "Checking if domain configuration exists..." "$yellow"
if [ -f "/etc/nginx/sites-available/$DOMAIN.conf" ]; then
    print_message "Domain configuration file exists: /etc/nginx/sites-available/$DOMAIN.conf" "$green"
    
    # Check if the configuration is enabled
    if [ -L "/etc/nginx/sites-enabled/$DOMAIN.conf" ]; then
        print_message "Domain configuration is enabled" "$green"
    else
        print_message "Domain configuration is not enabled!" "$red"
        print_message "Enable it with: sudo ln -s /etc/nginx/sites-available/$DOMAIN.conf /etc/nginx/sites-enabled/" "$yellow"
    fi
else
    print_message "Domain configuration file does not exist!" "$red"
    print_message "Create it with: ./setup_hwosecurity.sh" "$yellow"
fi
echo ""

# 4. Check RTMP module configuration
print_message "Checking RTMP module configuration..." "$yellow"
if grep -q "rtmp {" /etc/nginx/nginx.conf; then
    print_message "RTMP module is configured in nginx.conf" "$green"
else
    print_message "RTMP module is not configured in nginx.conf" "$red"
    print_message "This will cause issues with streaming. Run ./update.sh to fix." "$yellow"
fi
echo ""

# 5. Check for the stats location block that caused the previous error
print_message "Checking for problematic stats configuration..." "$yellow"
if grep -q "rtmp_stat all" /etc/nginx/sites-available/$DOMAIN.conf; then
    print_message "Problematic rtmp_stat directive found in domain configuration!" "$red"
    print_message "This will cause NGINX to fail. Run ./update.sh to fix this issue." "$yellow"
    
    # Show the problematic lines
    echo ""
    print_message "Problematic configuration (lines containing rtmp_stat):" "$yellow"
    grep -n "rtmp_stat" /etc/nginx/sites-available/$DOMAIN.conf
else
    print_message "No problematic rtmp_stat directives found in domain configuration" "$green"
fi
echo ""

# 6. Check stream directories
print_message "Checking stream directories..." "$yellow"
if [ -d "/var/www/stream/hls" ] && [ -d "/var/www/stream/dash" ]; then
    print_message "Stream directories exist" "$green"
    
    # Check permissions
    STREAM_PERMS=$(stat -c "%a" /var/www/stream)
    STREAM_OWNER=$(stat -c "%U:%G" /var/www/stream)
    
    print_message "Stream directory permissions: $STREAM_PERMS" "$green"
    print_message "Stream directory owner: $STREAM_OWNER" "$green"
    
    if [ "$STREAM_PERMS" != "755" ]; then
        print_message "Warning: Stream directory permissions should be 755" "$yellow"
        print_message "Fix with: sudo chmod 755 -R /var/www/stream" "$yellow"
    fi
    
    if [ "$STREAM_OWNER" != "www-data:www-data" ]; then
        print_message "Warning: Stream directory owner should be www-data:www-data" "$yellow"
        print_message "Fix with: sudo chown -R www-data:www-data /var/www/stream" "$yellow"
    fi
else
    print_message "Stream directories don't exist!" "$red"
    print_message "Create them with: sudo mkdir -p /var/www/stream/{hls,dash}" "$yellow"
    print_message "Set permissions with: sudo chmod 755 -R /var/www/stream" "$yellow"
    print_message "Set owner with: sudo chown -R www-data:www-data /var/www/stream" "$yellow"
fi
echo ""

# 7. DNS check
print_message "Checking DNS resolution for $DOMAIN..." "$yellow"
if command -v nslookup &> /dev/null; then
    nslookup $DOMAIN
    echo ""
    nslookup www.$DOMAIN
else
    print_message "nslookup is not installed. Installing..." "$yellow"
    apt-get update && apt-get install -y dnsutils
    
    nslookup $DOMAIN
    echo ""
    nslookup www.$DOMAIN
fi
echo ""

# 8. Print the most recent NGINX error log entries
print_message "Recent NGINX error log entries:" "$yellow"
if [ -f "/var/log/nginx/error.log" ]; then
    tail -n 20 /var/log/nginx/error.log
else
    print_message "NGINX error log not found" "$red"
fi
echo ""

# 9. Check domain-specific error log if it exists
if [ -f "/var/log/nginx/$DOMAIN-error.log" ]; then
    print_message "Recent domain-specific error log entries:" "$yellow"
    tail -n 20 "/var/log/nginx/$DOMAIN-error.log"
else
    print_message "Domain-specific error log not found" "$yellow"
fi
echo ""

# 10. Check if the NGINX process is running
print_message "Checking if NGINX is running..." "$yellow"
if pgrep nginx > /dev/null; then
    print_message "NGINX is running" "$green"
    echo ""
    print_message "NGINX processes:" "$green"
    ps aux | grep nginx | grep -v grep
else
    print_message "NGINX is not running!" "$red"
    print_message "Start it with: sudo systemctl start nginx" "$yellow"
fi
echo ""

# 11. Show listening ports
print_message "Checking listening ports..." "$yellow"
if command -v netstat &> /dev/null; then
    netstat -tulpn | grep -E ':(80|443|1935)' | grep nginx
elif command -v ss &> /dev/null; then
    ss -tulpn | grep -E ':(80|443|1935)' | grep nginx
else
    print_message "Neither netstat nor ss is installed" "$red"
fi
echo ""

# 12. Summary and recommendations
print_message "Diagnostic Summary" "$blue"
print_message "=================" "$blue"
echo ""

if nginx -t &> /dev/null; then
    print_message "✓ NGINX configuration appears to be valid" "$green"
else
    print_message "✗ NGINX configuration has errors. Run ./update.sh to fix them." "$red"
fi

if grep -q "rtmp {" /etc/nginx/nginx.conf; then
    print_message "✓ RTMP module is configured" "$green"
else
    print_message "✗ RTMP module is not configured. Run ./update.sh to fix." "$red"
fi

if [ -L "/etc/nginx/sites-enabled/$DOMAIN.conf" ]; then
    print_message "✓ Domain configuration is enabled" "$green"
else
    print_message "✗ Domain configuration is not enabled" "$red"
fi

if ! grep -q "rtmp_stat all" /etc/nginx/sites-available/$DOMAIN.conf 2>/dev/null; then
    print_message "✓ No problematic rtmp_stat directives found" "$green"
else
    print_message "✗ Problematic rtmp_stat directives found. Run ./update.sh to fix." "$red"
fi

if pgrep nginx > /dev/null; then
    print_message "✓ NGINX is running" "$green"
else
    print_message "✗ NGINX is not running" "$red"
fi

echo ""
print_message "Recommended actions:" "$blue"
echo "1. Run sudo ./update.sh to fix configuration errors"
echo "2. Make sure your domain DNS points to your server's IP address"
echo "3. Check that ports 80, 443, and 1935 are open in your firewall"
echo "4. Restart NGINX with: sudo systemctl restart nginx"
echo ""