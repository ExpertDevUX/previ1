#!/bin/bash

# Update script to fix NGINX configuration errors for hwosecurity.org
# This script fixes the "unknown directive 'rtmp_stat'" error

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    print_message "This script must be run as root. Try using sudo." "$red"
    exit 1
fi

# Domain name
DOMAIN="hwosecurity.org"

print_message "Fixing NGINX Configuration for $DOMAIN" "$blue"
print_message "=======================================" "$blue"
echo ""

# Backup current configuration
print_message "Creating backup of current configuration..." "$yellow"
if [ -f "/etc/nginx/sites-available/$DOMAIN.conf" ]; then
    cp "/etc/nginx/sites-available/$DOMAIN.conf" "/etc/nginx/sites-available/$DOMAIN.conf.bak"
fi

# Check if NGINX RTMP module is installed
if ! grep -q "rtmp {" /etc/nginx/nginx.conf; then
    print_message "RTMP module is not properly configured in nginx.conf" "$red"
    print_message "Adding RTMP configuration to nginx.conf..." "$yellow"
    
    # Create a backup
    cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup
    
    # Add RTMP configuration to nginx.conf if it doesn't exist
    cat > /etc/nginx/nginx.conf << 'EOF'
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 768;
    # multi_accept on;
}

# RTMP configuration for streaming
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        # RTMP application for live streaming
        application live {
            live on;
            record off;
            
            # HLS settings
            hls on;
            hls_path /var/www/stream/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # DASH settings
            dash on;
            dash_path /var/www/stream/dash;
            dash_fragment 3;
            dash_playlist_length 60;
        }
    }
}

http {
    # Basic settings
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    # SSL settings
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    
    # Logging settings
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;
    
    # Gzip settings
    gzip on;
    
    # Virtual Host Configs
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*.conf;
    
    # RTMP statistics stylesheet
    # Copy stat.xsl file
    server {
        listen 80;
        server_name localhost;
        
        # This is used with rtmp_stat directive
        location /stat.xsl {
            root /etc/nginx/;
        }
    }
}
EOF

    # Create the stat.xsl file
    print_message "Creating stat.xsl for RTMP statistics..." "$yellow"
    cat > /etc/nginx/stat.xsl << 'EOF'
<?xml version="1.0" encoding="utf-8" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:template match="/">
    <html>
        <head>
            <title>RTMP Statistics for hwosecurity.org</title>
            <meta charset="utf-8" />
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                    color: #333;
                    font-size: 14px;
                }
                h1, h2, h3, h4 {
                    margin: 0;
                    padding: 0;
                    color: #333;
                }
                h1 {
                    font-size: 24px;
                    margin: 0 0 20px 0;
                }
                h2 {
                    font-size: 20px;
                    margin: 0 0 15px 0;
                }
                h3 {
                    font-size: 16px;
                    margin: 10px 0;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin: 10px 0 30px 0;
                }
                th, td {
                    text-align: left;
                    padding: 8px;
                    border: 1px solid #ddd;
                }
                th {
                    background-color: #f2f2f2;
                }
                tr:nth-child(even) {
                    background-color: #f9f9f9;
                }
                .active {
                    color: green;
                }
                .inactive {
                    color: red;
                }
                .section {
                    background-color: #fff;
                    border-radius: 5px;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
                    padding: 20px;
                    margin-bottom: 20px;
                }
            </style>
        </head>
        <body>
            <h1>RTMP Statistics for hwosecurity.org</h1>
            <div class="section">
                <h2>NGINX Version <xsl:value-of select="rtmp/nginx_version"/> (pid: <xsl:value-of select="rtmp/nginx_pid"/>)</h2>
                <p>Uptime: <xsl:value-of select="rtmp/uptime"/></p>
                <p>Accepted connections: <xsl:value-of select="rtmp/naccepted"/></p>
            </div>
            <xsl:for-each select="rtmp/server">
                <div class="section">
                    <h2>Server <xsl:value-of select="@application"/> (port: <xsl:value-of select="@port"/>)</h2>
                    <xsl:for-each select="application">
                        <div class="section">
                            <h3>Application <xsl:value-of select="@name"/></h3>
                            <table>
                                <tr>
                                    <th>Type</th>
                                    <th>Count</th>
                                </tr>
                                <tr>
                                    <td>Live Streams</td>
                                    <td><xsl:value-of select="live/nclients"/></td>
                                </tr>
                                <tr>
                                    <td>Playing Streams</td>
                                    <td><xsl:value-of select="play/nclients"/></td>
                                </tr>
                            </table>
                            
                            <xsl:if test="count(live/stream) > 0">
                            <h3>Live Streams</h3>
                            <table>
                                <tr>
                                    <th>Stream Name</th>
                                    <th>Type</th>
                                    <th>Clients</th>
                                    <th>Time</th>
                                    <th>Bitrate (kb/s)</th>
                                </tr>
                                <xsl:for-each select="live/stream">
                                <tr>
                                    <td><xsl:value-of select="@name"/></td>
                                    <td><span class="active">live</span></td>
                                    <td><xsl:value-of select="nclients"/></td>
                                    <td><xsl:value-of select="time"/></td>
                                    <td><xsl:value-of select="bw_video div 1024"/></td>
                                </tr>
                                </xsl:for-each>
                            </table>
                            </xsl:if>
                            
                            <xsl:if test="count(live/stream/client) > 0">
                            <h3>Active Clients</h3>
                            <table>
                                <tr>
                                    <th>ID</th>
                                    <th>Address</th>
                                    <th>Time</th>
                                    <th>Flash version</th>
                                    <th>Protocol</th>
                                </tr>
                                <xsl:for-each select="live/stream/client">
                                <tr>
                                    <td><xsl:value-of select="@id"/></td>
                                    <td><xsl:value-of select="address"/></td>
                                    <td><xsl:value-of select="time"/></td>
                                    <td><xsl:value-of select="flashver"/></td>
                                    <td><xsl:value-of select="protocol"/></td>
                                </tr>
                                </xsl:for-each>
                            </table>
                            </xsl:if>
                        </div>
                    </xsl:for-each>
                </div>
            </xsl:for-each>
        </body>
    </html>
</xsl:template>
</xsl:stylesheet>
EOF

else
    print_message "RTMP module is already configured in nginx.conf" "$green"
fi

# Now fix the hwosecurity.org configuration by removing the stats location blocks
print_message "Fixing $DOMAIN virtual host configuration..." "$yellow"

cat > "/etc/nginx/sites-available/$DOMAIN.conf" << EOF
# NGINX configuration for hwosecurity.org
# RTMP, HLS, and DASH streaming

# HTTP Server for HLS/DASH and Web UI
server {
    listen 80;
    server_name hwosecurity.org www.hwosecurity.org;
    
    # Web application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # HLS streaming location
    location /hls {
        # Serve HLS fragments
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # DASH streaming location
    location /dash {
        # Serve DASH fragments
        types {
            application/dash+xml mpd;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # RTMP Statistics (proper directive usage)
    location /stats {
        # Stats displayed using HTTP
        root /var/www/stream;
        add_header Refresh "5; \$request_uri";
    }
    
    location /stat.xsl {
        root /etc/nginx/;
    }
    
    # Logging configuration
    access_log /var/log/nginx/hwosecurity.org-access.log;
    error_log /var/log/nginx/hwosecurity.org-error.log;
}
EOF

# Make sure the stream directories exist
print_message "Creating stream directories..." "$yellow"
mkdir -p /var/www/stream/hls
mkdir -p /var/www/stream/dash
chmod 755 -R /var/www/stream
chown -R www-data:www-data /var/www/stream

# Test NGINX configuration
print_message "Testing NGINX configuration..." "$green"
if nginx -t; then
    # Reload NGINX to apply changes
    print_message "NGINX configuration is valid. Reloading NGINX..." "$green"
    systemctl reload nginx
    
    print_message "Fix completed successfully!" "$green"
    echo ""
    print_message "Your streaming URLs:" "$yellow"
    echo "RTMP: rtmp://$DOMAIN/live/stream-key"
    echo "HLS: http://$DOMAIN/hls/stream-key.m3u8"
    echo "DASH: http://$DOMAIN/dash/stream-key.mpd"
    echo ""
    print_message "Web Application:" "$yellow"
    echo "http://$DOMAIN/"
    echo ""
    print_message "Stream Statistics (view with browser):" "$yellow"
    echo "http://$DOMAIN/stats"
    echo ""
else
    print_message "NGINX configuration test failed. Please check the errors above." "$red"
    print_message "Restoring backup configuration..." "$yellow"
    
    # Restore from backup if available
    if [ -f "/etc/nginx/sites-available/$DOMAIN.conf.bak" ]; then
        cp "/etc/nginx/sites-available/$DOMAIN.conf.bak" "/etc/nginx/sites-available/$DOMAIN.conf"
    fi
    if [ -f "/etc/nginx/nginx.conf.backup" ]; then
        cp "/etc/nginx/nginx.conf.backup" "/etc/nginx/nginx.conf"
    fi
    
    exit 1
fi