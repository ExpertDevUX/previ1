# RTMP Stream Viewer

A lightweight web application for previewing and checking RTMP, HLS, and DASH streams. The application displays live video streams in a small, fixed-size player (240x135px) with a compact interface.

## Features

- Support for multiple streaming protocols: RTMP, HLS, and DASH
- Compact video player (240x135px) for quick previews
- Stream status monitoring and auto-refresh
- Embeddable player for sharing streams in iframes
- Easy setup and portable installation
- Advanced streaming server installation script
- Complete FFmpeg streaming tools and guides
- OBS Studio integration for live streaming

## Quick Start

### Running on Replit

1. Click the Run button to start the application
2. Enter an RTMP, HLS, or DASH URL in the input field
3. Click "Load Stream" to view the preview

### Local Installation

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/rtmp-stream-viewer.git
   cd rtmp-stream-viewer
   ```

2. Run the setup script:
   ```bash
   ./setup.sh
   ```

3. Start the application in production mode:
   ```bash
   ./start_prod.sh
   ```

4. Open a browser and navigate to:
   ```
   http://localhost:5000
   ```

## Supported Stream Formats

- **RTMP**: `rtmp://example.com/live/stream-key`
- **HLS**: `http://example.com/hls/stream-key.m3u8`
- **DASH**: `http://example.com/dash/stream-key.mpd`

## Setting Up Your Own RTMP Server

This repository includes an automated script to set up a complete NGINX-based RTMP server with HLS and DASH support.

### Automatic Installation

1. Make the installation script executable:
   ```bash
   chmod +x install_nginx_rtmp.sh
   ```

2. Run the script with sudo:
   ```bash
   sudo ./install_nginx_rtmp.sh
   ```

For detailed instructions, see the [RTMP Server Guide](RTMP_SERVER_GUIDE.md).

### Domain Configuration

If you want to use a custom domain (like hwosecurity.org) with your RTMP server:

1. Make sure your domain's DNS points to your server's IP address

2. Run the domain setup script:
   ```bash
   sudo ./domain_setup.sh your-domain.com
   ```

3. For HTTPS support, install SSL certificates:
   ```bash
   sudo certbot --nginx -d your-domain.com -d www.your-domain.com
   ```

For detailed domain setup instructions, see the [Domain Setup Guide](DOMAIN_SETUP_GUIDE.md).

## Streaming to Your RTMP Server

### Using OBS Studio

1. Open OBS Studio and go to Settings → Stream
2. Select "Custom" as the service
3. Set the Server URL to: `rtmp://your-server-ip/live`
4. Set the Stream Key to any name (e.g., `mystream`)
5. Click "Start Streaming"

Your stream will be available at:
- RTMP: `rtmp://your-server-ip/live/mystream`
- HLS: `http://your-server-ip/hls/mystream.m3u8`
- DASH: `http://your-server-ip/dash/mystream.mpd`

### Using FFmpeg

Use the included FFmpeg tools to stream video files, webcam, or desktop:

```bash
# Stream a video file
./stream_with_ffmpeg.sh -i video.mp4 -s rtmp://your-server-ip/live -k mystream

# Stream from webcam
./stream_with_ffmpeg.sh -w -s rtmp://your-server-ip/live -k webcam

# Stream desktop
./stream_with_ffmpeg.sh -d -s rtmp://your-server-ip/live -k desktop
```

For more FFmpeg commands, see the [FFmpeg Streaming Guide](FFMPEG_STREAMING_GUIDE.md) or the quick reference [FFmpeg QuickRef](FFMPEG_QUICKREF.md).

### Generate Test Video

Create test content for streaming:

```bash
./generate_test_video.sh -d 30 -o test_video.mp4
```

## Embedding the Player

You can embed the stream viewer in other web pages using an iframe:

```html
<!-- Embed HLS stream -->
<iframe src="http://your-server/embed?url=http://your-server-ip/hls/mystream.m3u8" 
        width="240" height="135" frameborder="0" allowfullscreen></iframe>

<!-- Embed RTMP stream -->
<iframe src="http://your-server/embed?url=rtmp://your-server-ip/live/mystream" 
        width="240" height="135" frameborder="0" allowfullscreen></iframe>
```

## Command Line Options

When running the application using `run.py`, you can specify various command-line options:

```bash
python run.py --port 8080 --host 0.0.0.0 --debug
```

Available options:
- `--port`: Port to listen on (default: 5000)
- `--host`: Host to bind to (default: 127.0.0.1)
- `--debug`: Enable debug mode
- `--workers`: Number of worker processes (for Gunicorn, default: 4)
- `--prod`: Use Gunicorn for production deployment

## Project Structure

```
rtmp-stream-viewer/
├── streamviewer/          # Main package directory
│   └── __init__.py        # Application factory and routes
├── static/                # Static assets
│   ├── css/               # CSS stylesheets
│   ├── js/                # JavaScript files
│   └── img/               # Images
├── templates/             # HTML templates
├── main.py                # Application entry point
├── wsgi.py                # WSGI entry point
├── run.py                 # Command-line runner
├── setup.py               # Package installation script
├── setup.sh               # Setup script
├── start_dev.sh           # Development server starter
├── start_prod.sh          # Production server starter
├── install_nginx_rtmp.sh  # RTMP server installer
├── domain_setup.sh        # Domain configuration script
├── venv_demo.sh           # Virtual environment demo
├── stream_with_ffmpeg.sh  # FFmpeg streaming helper
├── generate_test_video.sh # Test video generator
├── FFMPEG_STREAMING_GUIDE.md  # Detailed FFmpeg guide
├── FFMPEG_QUICKREF.md     # FFmpeg command reference
├── RTMP_SERVER_GUIDE.md   # NGINX RTMP server setup guide
└── DOMAIN_SETUP_GUIDE.md  # Domain configuration guide
```

## Virtual Environment

When installed with the setup script, the application runs in a Python virtual environment. To activate it manually:

```bash
source venv/bin/activate
```

To deactivate:

```bash
deactivate
```

## Dependencies

- Flask: Web framework
- Flask-CORS: Cross-origin resource sharing
- Gunicorn: WSGI HTTP server
- Video.js: JavaScript video player (included)

## Browser Compatibility

- Chrome/Edge/Firefox: Full support for HLS and DASH
- Safari: HLS support built-in
- Mobile browsers: HLS support on most browsers

## Troubleshooting

### Stream Not Working?

1. Check if your RTMP server is running: `systemctl status nginx`
2. Verify that ports 1935 (RTMP), 80 (HTTP), and 443 (HTTPS) are open
3. Ensure your stream key is used consistently in both publishing and viewing
4. Try viewing the HLS stream directly in VLC or a browser: `http://your-server-ip/hls/stream-key.m3u8`

### Domain Issues

1. **DNS Not Resolving**: Check that your domain's DNS A record points to your server's IP address
   ```bash
   nslookup hwosecurity.org
   ```

2. **NGINX Configuration Error**: Verify your NGINX configuration is valid
   ```bash
   sudo nginx -t
   ```
   
3. **Permission Issues**: Check directory permissions
   ```bash
   sudo chmod 755 -R /var/www/stream
   sudo chown -R www-data:www-data /var/www/stream
   ```

4. **SSL Certificate Problems**: Check certificate status and renew if needed
   ```bash
   sudo certbot certificates
   sudo certbot renew --dry-run
   ```

### Common Issues

- **High CPU Usage**: Lower your encoding preset in OBS or FFmpeg
- **Stream Delays**: Adjust the HLS fragment size in nginx.conf
- **Playback Issues**: Try different protocols (HLS usually has the best compatibility)
- **Domain Not Working**: Run the domain setup script with your domain name
  ```bash
  sudo ./domain_setup.sh hwosecurity.org
  ```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- [Video.js](https://videojs.com/) for the video player
- [NGINX RTMP Module](https://github.com/arut/nginx-rtmp-module) for the streaming server
- [Flask](https://flask.palletsprojects.com/) for the web framework
- [FFmpeg](https://ffmpeg.org/) for streaming tools
- [OBS Studio](https://obsproject.com/) for broadcasting software