#!/bin/bash
# fix_ssl_config.sh - Fix SSL configuration issues in NGINX for hwosecurity.org

set -e

echo "Fixing SSL configuration issues for hwosecurity.org..."

# Check for root privileges
if [ "$(id -u)" -ne 0 ]; then
  echo "This script needs to be run with sudo or as root."
  exit 1
fi

# Path to the site configuration
CONF_PATH="/etc/nginx/sites-enabled/hwosecurity.org.conf"

# Check if the configuration file exists
if [ ! -f "$CONF_PATH" ]; then
  echo "Error: Configuration file not found: $CONF_PATH"
  echo "Using local version instead..."
  CONF_PATH="hwosecurity.org.conf"
  if [ ! -f "$CONF_PATH" ]; then
    echo "Error: Local configuration file also not found."
    exit 1
  fi
fi

echo "Backing up original configuration..."
cp "$CONF_PATH" "${CONF_PATH}.bak.$(date +%Y%m%d%H%M%S)"

echo "Checking for SSL directive issues..."

# Fix 1: Replace deprecated 'ssl' directive with 'listen ... ssl'
sed -i 's/listen 443;.*ssl;/listen 443 ssl;/g' "$CONF_PATH"

# Fix 2: Check if there are uncommented SSL server blocks without certificates
if grep -q "listen.*443.*ssl" "$CONF_PATH" && ! grep -q "ssl_certificate" "$CONF_PATH"; then
  echo "Found SSL server block without certificates. Adding the required directives..."
  # Comment out the SSL server block
  sed -i '/listen.*443.*ssl/,/}/s/^/#/' "$CONF_PATH"
  echo "SSL server block commented out to prevent configuration errors."
fi

# Fix 3: If both issues are present, use the simple configuration
if grep -E -q "ssl_certificate.*ssl_certificate_key" "$CONF_PATH" && grep -q "listen.*443.*ssl" "$CONF_PATH"; then
  # There might be SSL configuration but something is still wrong
  # Let's ensure proper formatting for the ssl_certificate directive
  sed -i 's/#\s*ssl_certificate/ssl_certificate/g' "$CONF_PATH"
  sed -i 's/#\s*ssl_certificate_key/ssl_certificate_key/g' "$CONF_PATH"
fi

# Fix 4: Alternative - use the simple configuration
if [ -f "hwosecurity.org.simple.conf" ]; then
  echo "Would you like to use the simplified configuration instead? (y/n)"
  read -r response
  if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
    echo "Applying simplified configuration..."
    cp "hwosecurity.org.simple.conf" "$CONF_PATH"
    echo "Simplified configuration applied."
  fi
fi

echo "Testing NGINX configuration..."
nginx -t

if [ $? -eq 0 ]; then
  echo "Configuration test successful."
  echo "Reloading NGINX..."
  systemctl reload nginx
  echo "NGINX configuration has been fixed and reloaded."
else
  echo "Configuration test failed. The configuration may need manual adjustment."
  echo "No changes have been applied to the running NGINX service."
fi

echo "Done."