# FFmpeg Quick Reference for RTMP Streaming

## Most Common FFmpeg Commands

### Stream a Video File to RTMP Server
```bash
ffmpeg -re -i video.mp4 -c:v libx264 -preset veryfast -b:v 1500k -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key
```

### Stream a Test Pattern (when you don't have a video file)
```bash
ffmpeg -f lavfi -i testsrc=size=1280x720:rate=30 -f lavfi -i sine=frequency=1000:sample_rate=44100 -c:v libx264 -preset veryfast -b:v 1500k -c:a aac -b:a 128k -t 60 -f flv rtmp://your-server-ip/live/stream-key
```

### Stream from Webcam
```bash
# Linux
ffmpeg -f v4l2 -i /dev/video0 -f alsa -i hw:0 -c:v libx264 -preset ultrafast -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key

# macOS
ffmpeg -f avfoundation -i "0:0" -c:v libx264 -preset ultrafast -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key

# Windows
ffmpeg -f dshow -i video="Webcam":audio="Microphone" -c:v libx264 -preset ultrafast -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key
```

### Stream Desktop
```bash
# Linux
ffmpeg -f x11grab -i :0.0 -f pulse -i default -c:v libx264 -preset ultrafast -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key

# macOS
ffmpeg -f avfoundation -i "1:0" -c:v libx264 -preset ultrafast -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key

# Windows
ffmpeg -f gdigrab -i desktop -f dshow -i audio="Microphone" -c:v libx264 -preset ultrafast -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key
```

### Loop a Video Indefinitely
```bash
ffmpeg -stream_loop -1 -re -i video.mp4 -c:v libx264 -preset veryfast -b:v 1500k -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key
```

### Stream with Overlay Text
```bash
ffmpeg -re -i video.mp4 -vf "drawtext=text='Live Stream':fontcolor=white:fontsize=24:box=1:boxcolor=black@0.5:x=10:y=10" -c:v libx264 -preset veryfast -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key
```

### Stream YouTube Video (requires youtube-dl)
```bash
youtube-dl -f best -g "https://www.youtube.com/watch?v=VIDEO_ID" | ffmpeg -re -i - -c:v libx264 -preset veryfast -b:v 1500k -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/stream-key
```

### Help Using the Included Script
```bash
# Stream a video file
./stream_with_ffmpeg.sh -i video.mp4 -s rtmp://your-server-ip/live -k stream-key

# Stream from webcam
./stream_with_ffmpeg.sh -w -s rtmp://your-server-ip/live -k webcam-stream

# Stream from desktop
./stream_with_ffmpeg.sh -d -s rtmp://your-server-ip/live -k desktop-stream

# Loop a video file with higher quality
./stream_with_ffmpeg.sh -i video.mp4 -s rtmp://your-server-ip/live -k loop-stream -l -v 2500k
```

## Common Streaming Parameters

- `-c:v libx264`: Use H.264 video codec
- `-preset`: Encoding speed vs compression (ultrafast, superfast, veryfast, faster, fast, medium)
- `-b:v 1500k`: Video bitrate
- `-c:a aac`: Use AAC audio codec
- `-b:a 128k`: Audio bitrate
- `-f flv`: Output format as FLV (for RTMP)
- `-re`: Read input at native framerate
- `-stream_loop -1`: Loop input indefinitely