/**
 * RTMP Stream Viewer
 * Handles the RTMP/HLS video player and stream monitoring
 */

let player;
let streamCheckInterval;
let currentStreamUrl = '';

// Initialize the application when the DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the video.js player with HLS and DASH support
    player = videojs('rtmp-player', {
        techOrder: ['html5'],
        autoplay: false,
        controls: true,
        fluid: true,
        preload: 'auto',
        playbackRates: [0.5, 1, 1.5, 2],
        html5: {
            hls: {
                enableLowInitialPlaylist: true,
                smoothQualityChange: true,
                overrideNative: true
            },
            nativeAudioTracks: false,
            nativeVideoTracks: false
        },
        // Better DASH support
        liveui: true,
        liveTracker: {
            trackingThreshold: 0.5,
            liveTolerance: 15
        },
        controlBar: {
            playToggle: true,
            volumePanel: true,
            currentTimeDisplay: true,
            timeDivider: true,
            durationDisplay: true,
            progressControl: true,
            fullscreenToggle: true,
            pictureInPictureToggle: true,
            qualitySelector: true
        }
    });
    
    // Handle form submission
    const streamForm = document.getElementById('stream-form');
    if (streamForm) {
        streamForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const rtmpUrl = document.getElementById('rtmp-url').value.trim();
            if (rtmpUrl) {
                initializePlayer(rtmpUrl);
                updateEmbedCode(rtmpUrl);
            } else {
                showAlert('Please enter a valid RTMP URL', 'danger');
            }
        });
    }
    
    // Handle copy embed code button
    const copyEmbedBtn = document.getElementById('copy-embed-btn');
    if (copyEmbedBtn) {
        copyEmbedBtn.addEventListener('click', function() {
            const embedCode = document.getElementById('embed-code');
            embedCode.select();
            document.execCommand('copy');
            
            // Show feedback
            const originalText = copyEmbedBtn.innerHTML;
            copyEmbedBtn.innerHTML = '<i class="fas fa-check me-1"></i> Copied!';
            copyEmbedBtn.classList.remove('btn-secondary');
            copyEmbedBtn.classList.add('btn-success');
            
            setTimeout(function() {
                copyEmbedBtn.innerHTML = originalText;
                copyEmbedBtn.classList.remove('btn-success');
                copyEmbedBtn.classList.add('btn-secondary');
            }, 2000);
        });
    }
    
    // Set up stream monitoring
    player.on('playing', function() {
        updateStreamStatus('online');
        startMonitoring();
    });
    
    player.on('error', function() {
        updateStreamStatus('error');
        stopMonitoring();
    });
    
    player.on('waiting', function() {
        updateStreamStatus('buffering');
    });
    
    player.on('ended', function() {
        updateStreamStatus('ended');
        stopMonitoring();
    });
});

/**
 * Initialize the video player with the given RTMP URL
 * @param {string} rtmpUrl - The RTMP URL to stream
 */
function initializePlayer(rtmpUrl) {
    if (!rtmpUrl) return;
    
    currentStreamUrl = rtmpUrl;
    updateStreamStatus('connecting');
    
    // Check if we need to convert RTMP to HLS or can play directly
    let sourceUrl = rtmpUrl;
    
    // Show different messages based on URL type
    if (rtmpUrl.startsWith('rtmp://')) {
        // For RTMP streams - check availability and show browser compatibility warning
        checkStreamAvailability(rtmpUrl);
        showAlert('Note: Direct RTMP playback may not be supported in all browsers. Consider using HLS if available.', 'info');
    } else if (rtmpUrl.includes('.m3u8') || rtmpUrl.includes('/hls/')) {
        // For HLS streams - better browser compatibility
        checkStreamAvailability(rtmpUrl);
        showAlert('HLS stream detected. This format has better browser compatibility.', 'success');
    } else if (rtmpUrl.includes('.mpd') || rtmpUrl.includes('/dash/')) {
        // For DASH streams
        checkStreamAvailability(rtmpUrl);
        showAlert('DASH stream detected. This format has good browser compatibility.', 'success');
    } else {
        // For other stream types
        checkStreamAvailability(rtmpUrl);
        showAlert('Stream format auto-detection enabled. Playing as best-compatible format.', 'info');
    }
    
    // Use appropriate source based on URL type
    player.src({
        src: sourceUrl,
        type: determineSourceType(sourceUrl)
    });
    
    // Try to play the video
    player.load();
    
    // Try to autoplay but handle failure gracefully (many browsers block autoplay)
    const playPromise = player.play();
    
    if (playPromise !== undefined) {
        playPromise.catch(error => {
            console.log('Autoplay prevented:', error);
            // Show play button and wait for user interaction
            player.pause();
            updateStreamStatus('ready');
        });
    }
}

/**
 * Determine the MIME type based on the source URL
 * @param {string} url - The source URL
 * @returns {string} The appropriate MIME type
 */
function determineSourceType(url) {
    // HLS format
    if (url.includes('.m3u8') || url.includes('/hls/')) {
        return 'application/x-mpegURL';
    } 
    // DASH format
    else if (url.includes('.mpd') || url.includes('/dash/')) {
        return 'application/dash+xml';
    }
    // RTMP format 
    else if (url.startsWith('rtmp://')) {
        return 'rtmp/mp4';
    }
    // MP4 direct playback
    else if (url.includes('.mp4')) {
        return 'video/mp4';
    }
    // Try to determine based on other patterns
    else if (url.includes('/live/')) {
        // Many streaming setups use /live/ in the path
        // We'll try HLS first as it has better browser compatibility
        return 'application/x-mpegURL';
    }
    else {
        // Default to HLS as it has the best compatibility
        console.log('Unable to determine stream type from URL, defaulting to HLS');
        return 'application/x-mpegURL';
    }
}

/**
 * Check if the stream is available
 * @param {string} url - The stream URL to check
 */
function checkStreamAvailability(url) {
    fetch('/check-stream', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: url })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'online') {
            updateStreamStatus('online');
        } else {
            updateStreamStatus('offline');
        }
    })
    .catch(error => {
        console.error('Error checking stream:', error);
        updateStreamStatus('error');
    });
}

/**
 * Update the stream status indicator
 * @param {string} status - The current stream status
 */
function updateStreamStatus(status) {
    const statusElement = document.getElementById('stream-status');
    const infoStatus = document.getElementById('info-status');
    
    if (!statusElement) return;
    
    // Remove previous status classes
    statusElement.querySelector('.badge').className = 'badge';
    
    // Update status based on the current state
    switch (status) {
        case 'connecting':
            statusElement.querySelector('.badge').className = 'badge text-bg-info';
            statusElement.querySelector('.badge').innerHTML = '<i class="fas fa-circle-notch fa-spin me-1"></i> Connecting...';
            if (infoStatus) {
                infoStatus.className = 'badge text-bg-info';
                infoStatus.textContent = 'Connecting';
            }
            break;
        case 'online':
            statusElement.querySelector('.badge').className = 'badge text-bg-success';
            statusElement.querySelector('.badge').innerHTML = '<i class="fas fa-circle me-1"></i> Stream Online';
            setTimeout(() => {
                statusElement.style.opacity = '0';
            }, 3000);
            if (infoStatus) {
                infoStatus.className = 'badge text-bg-success';
                infoStatus.textContent = 'Online';
            }
            break;
        case 'offline':
            statusElement.querySelector('.badge').className = 'badge text-bg-danger';
            statusElement.querySelector('.badge').innerHTML = '<i class="fas fa-exclamation-circle me-1"></i> Stream Offline';
            statusElement.style.opacity = '1';
            if (infoStatus) {
                infoStatus.className = 'badge text-bg-danger';
                infoStatus.textContent = 'Offline';
            }
            break;
        case 'error':
            statusElement.querySelector('.badge').className = 'badge text-bg-danger';
            statusElement.querySelector('.badge').innerHTML = '<i class="fas fa-exclamation-triangle me-1"></i> Stream Error';
            statusElement.style.opacity = '1';
            if (infoStatus) {
                infoStatus.className = 'badge text-bg-danger';
                infoStatus.textContent = 'Error';
            }
            break;
        case 'buffering':
            statusElement.querySelector('.badge').className = 'badge text-bg-warning';
            statusElement.querySelector('.badge').innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Buffering...';
            statusElement.style.opacity = '1';
            if (infoStatus) {
                infoStatus.className = 'badge text-bg-warning';
                infoStatus.textContent = 'Buffering';
            }
            break;
        case 'ended':
            statusElement.querySelector('.badge').className = 'badge text-bg-secondary';
            statusElement.querySelector('.badge').innerHTML = '<i class="fas fa-stop-circle me-1"></i> Stream Ended';
            statusElement.style.opacity = '1';
            if (infoStatus) {
                infoStatus.className = 'badge text-bg-secondary';
                infoStatus.textContent = 'Ended';
            }
            break;
        case 'ready':
            statusElement.querySelector('.badge').className = 'badge text-bg-primary';
            statusElement.querySelector('.badge').innerHTML = '<i class="fas fa-play-circle me-1"></i> Ready to Play';
            statusElement.style.opacity = '1';
            if (infoStatus) {
                infoStatus.className = 'badge text-bg-primary';
                infoStatus.textContent = 'Ready';
            }
            break;
        default:
            statusElement.querySelector('.badge').className = 'badge text-bg-secondary';
            statusElement.querySelector('.badge').innerHTML = '<i class="fas fa-question-circle me-1"></i> Unknown Status';
            if (infoStatus) {
                infoStatus.className = 'badge text-bg-secondary';
                infoStatus.textContent = 'Unknown';
            }
    }
}

/**
 * Start monitoring the stream
 */
function startMonitoring() {
    // Clear any existing interval
    stopMonitoring();
    
    // Update stream information every 2 seconds
    streamCheckInterval = setInterval(updateStreamInformation, 2000);
}

/**
 * Stop monitoring the stream
 */
function stopMonitoring() {
    if (streamCheckInterval) {
        clearInterval(streamCheckInterval);
        streamCheckInterval = null;
    }
}

/**
 * Update stream information in the UI
 */
function updateStreamInformation() {
    if (!player) return;
    
    const infoResolution = document.getElementById('info-resolution');
    const infoBitrate = document.getElementById('info-bitrate');
    const infoBuffer = document.getElementById('info-buffer');
    
    if (!infoResolution || !infoBitrate || !infoBuffer) return;
    
    // Get video resolution
    const videoWidth = player.videoWidth();
    const videoHeight = player.videoHeight();
    if (videoWidth && videoHeight) {
        infoResolution.textContent = `${videoWidth}x${videoHeight}`;
    } else {
        infoResolution.textContent = 'Unknown';
    }
    
    // Bitrate is not directly available in video.js without additional plugins
    // In a real implementation, you would need to calculate this or get it from your player
    infoBitrate.textContent = 'Not available';
    
    // Buffer info
    const bufferLength = player.buffered().length;
    if (bufferLength > 0) {
        const bufferEnd = player.buffered().end(bufferLength - 1);
        const bufferStart = player.buffered().start(bufferLength - 1);
        const bufferSeconds = (bufferEnd - bufferStart).toFixed(1);
        infoBuffer.textContent = `${bufferSeconds}s`;
    } else {
        infoBuffer.textContent = '0s';
    }
}

/**
 * Update the embed code in the UI
 * @param {string} rtmpUrl - The stream URL to embed
 */
function updateEmbedCode(rtmpUrl) {
    const embedCodeElement = document.getElementById('embed-code');
    if (!embedCodeElement) return;
    
    // Create a proper embed URL with domain preference
    // First try to use hwosecurity.org if we're on that domain
    let origin = window.location.origin;
    let host = window.location.host;
    
    // If we're on hwosecurity.org domain, ensure we use it for the embed code
    if (host === 'hwosecurity.org' || host === 'www.hwosecurity.org') {
        origin = host.startsWith('www.') ? 'https://www.hwosecurity.org' : 'https://hwosecurity.org';
    }
    
    const embedUrl = `${origin}/embed?url=${encodeURIComponent(rtmpUrl)}`;
    
    embedCodeElement.value = `<iframe src="${embedUrl}" width="240" height="135" frameborder="0" allowfullscreen></iframe>`;
}

/**
 * Show an alert message to the user
 * @param {string} message - The message to display
 * @param {string} type - The alert type (success, danger, warning, info)
 */
function showAlert(message, type = 'info') {
    // Check if an alert container exists, if not create one
    let alertContainer = document.getElementById('alert-container');
    
    if (!alertContainer) {
        alertContainer = document.createElement('div');
        alertContainer.id = 'alert-container';
        alertContainer.className = 'alert-container position-fixed top-0 start-50 translate-middle-x p-3';
        alertContainer.style.zIndex = '1050';
        document.body.appendChild(alertContainer);
    }
    
    // Create the alert element
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.role = 'alert';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Add the alert to the container
    alertContainer.appendChild(alert);
    
    // Remove the alert after 5 seconds
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => {
            alertContainer.removeChild(alert);
        }, 150);
    }, 5000);
}
