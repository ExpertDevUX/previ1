#!/usr/bin/env python3
"""
Test script for RTMP Stream Viewer module
This script demonstrates how to use the streamviewer module in other projects
"""

import os
from streamviewer import create_app

def main():
    """Run a simple test of the streamviewer module"""
    print("Testing RTMP Stream Viewer module...")
    
    # Create the Flask application instance
    app = create_app({
        'DEBUG': True,
        'TESTING': True
    })
    
    # Print some info about the app
    print(f"App name: {app.name}")
    print(f"Debug mode: {app.debug}")
    print(f"Testing mode: {app.testing}")
    print(f"Routes:")
    for rule in app.url_map.iter_rules():
        print(f"  {rule.endpoint}: {rule.rule}")
    
    print("\nTest complete.")
    
    # Run the application on a different port
    if os.environ.get('RUN_APP', 'false').lower() == 'true':
        print("\nStarting test server on port 5001...")
        app.run(host='0.0.0.0', port=5001, debug=True)

if __name__ == '__main__':
    main()