#!/bin/bash

# Domain Configuration Script for RTMP Stream Viewer
# This script configures NGINX to work with your domain for streaming

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    print_message "This script must be run as root. Try using sudo." "$red"
    exit 1
fi

# Domain name to configure (default or specified by user)
DOMAIN=${1:-"hwosecurity.org"}

print_message "Domain Configuration for RTMP Server" "$blue"
print_message "===================================" "$blue"
echo ""
print_message "Configuring for domain: $DOMAIN" "$yellow"
echo ""

# Check if NGINX is installed
if ! command -v nginx &> /dev/null; then
    print_message "NGINX is not installed. Please run install_nginx_rtmp.sh first." "$red"
    exit 1
fi

# Create NGINX site configuration for the domain
print_message "Creating NGINX site configuration..." "$green"

# Create NGINX configuration
cat > /etc/nginx/sites-available/$DOMAIN.conf << EOF
# NGINX configuration for $DOMAIN
# RTMP, HLS, and DASH streaming

# HTTP Server for HLS/DASH and Web UI
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    
    # Redirect all HTTP traffic to HTTPS
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl;
    server_name $DOMAIN www.$DOMAIN;
    
    # SSL configuration
    # Uncomment these lines once you have SSL certificates
    # ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    # ssl_protocols TLSv1.2 TLSv1.3;
    # ssl_prefer_server_ciphers on;
    # ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    
    # For now, since SSL is commented out, allow HTTP
    ssl off;
    
    # Web application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # HLS streaming location
    location /hls {
        # Serve HLS fragments
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # DASH streaming location
    location /dash {
        # Serve DASH fragments
        types {
            application/dash+xml mpd;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # Simple stats page
    location /stats {
        rtmp_stat all;
        rtmp_stat_stylesheet stat.xsl;
        add_header Refresh "5; \$request_uri";
    }
    
    location /stat.xsl {
        root /etc/nginx/;
    }
    
    # Logging configuration
    access_log /var/log/nginx/$DOMAIN-access.log;
    error_log /var/log/nginx/$DOMAIN-error.log;
}
EOF

# Create symbolic link to enable the site
if [ -d "/etc/nginx/sites-enabled" ]; then
    print_message "Enabling site configuration..." "$green"
    ln -sf /etc/nginx/sites-available/$DOMAIN.conf /etc/nginx/sites-enabled/
fi

# Create directory structure if it doesn't exist
if [ ! -d "/var/www/stream/hls" ] || [ ! -d "/var/www/stream/dash" ]; then
    print_message "Creating stream directories..." "$green"
    mkdir -p /var/www/stream/hls
    mkdir -p /var/www/stream/dash
    chmod 755 -R /var/www/stream
    chown -R www-data:www-data /var/www/stream
fi

# Add domain-specific options to main NGINX RTMP configuration
print_message "Updating main NGINX configuration..." "$green"

# Create a backup of the original nginx.conf
cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup

# Check if we need to insert the include directive for sites-enabled
if ! grep -q "include /etc/nginx/sites-enabled/\*.conf;" /etc/nginx/nginx.conf; then
    # Add the include directive for site-specific configurations
    sed -i '/http {/a \    include /etc/nginx/sites-enabled/*.conf;' /etc/nginx/nginx.conf
fi

# Test NGINX configuration
print_message "Testing NGINX configuration..." "$green"
nginx -t

if [ $? -eq 0 ]; then
    # Reload NGINX to apply changes
    print_message "Reloading NGINX..." "$green"
    systemctl reload nginx
    
    print_message "Domain configuration completed successfully!" "$green"
    echo ""
    print_message "Your streaming URLs:" "$yellow"
    echo "RTMP: rtmp://$DOMAIN/live/stream-key"
    echo "HLS: https://$DOMAIN/hls/stream-key.m3u8"
    echo "DASH: https://$DOMAIN/dash/stream-key.mpd"
    echo ""
    print_message "Web Application:" "$yellow"
    echo "https://$DOMAIN/"
    echo ""
    print_message "Stream Statistics:" "$yellow"
    echo "https://$DOMAIN/stats"
    echo ""
    
    # SSL information
    print_message "SSL Certificate Setup:" "$yellow"
    echo "To enable HTTPS, install Certbot and run:"
    echo "  sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN"
    echo "Then uncomment the SSL configuration lines in:"
    echo "  /etc/nginx/sites-available/$DOMAIN.conf"
    echo ""
else
    print_message "NGINX configuration test failed. Please check the errors above." "$red"
    # Restore the backup
    cp /etc/nginx/nginx.conf.backup /etc/nginx/nginx.conf
    exit 1
fi