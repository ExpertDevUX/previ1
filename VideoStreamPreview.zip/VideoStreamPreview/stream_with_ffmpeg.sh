#!/bin/bash

# Stream with FFmpeg - Helper Script
# This script helps stream content to an RTMP server using FFmpeg

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Default values
SERVER_URL=""
STREAM_KEY="stream"
INPUT_FILE=""
VIDEO_BITRATE="1500k"
AUDIO_BITRATE="128k"
PRESET="veryfast"

# Function to display help
show_help() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  -i, --input FILE       Input file to stream (required)"
    echo "  -s, --server URL       RTMP server URL (required)"
    echo "  -k, --key KEY          Stream key (default: stream)"
    echo "  -v, --video-bitrate BR Video bitrate (default: 1500k)"
    echo "  -a, --audio-bitrate BR Audio bitrate (default: 128k)"
    echo "  -p, --preset PRESET    x264 preset (default: veryfast)"
    echo "                         Options: ultrafast, superfast, veryfast, faster, fast, medium"
    echo "  -l, --loop             Loop the input indefinitely"
    echo "  -w, --webcam           Use webcam as input"
    echo "  -d, --desktop          Capture desktop as input"
    echo "  -h, --help             Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 -i video.mp4 -s rtmp://example.com/live -k mystream"
    echo "  $0 -w -s rtmp://example.com/live -k webcam"
    echo "  $0 -d -s rtmp://example.com/live -k desktop"
    echo ""
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -i|--input)
            INPUT_FILE="$2"
            shift
            shift
            ;;
        -s|--server)
            SERVER_URL="$2"
            shift
            shift
            ;;
        -k|--key)
            STREAM_KEY="$2"
            shift
            shift
            ;;
        -v|--video-bitrate)
            VIDEO_BITRATE="$2"
            shift
            shift
            ;;
        -a|--audio-bitrate)
            AUDIO_BITRATE="$2"
            shift
            shift
            ;;
        -p|--preset)
            PRESET="$2"
            shift
            shift
            ;;
        -l|--loop)
            LOOP="-stream_loop -1"
            shift
            ;;
        -w|--webcam)
            USE_WEBCAM=true
            shift
            ;;
        -d|--desktop)
            USE_DESKTOP=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            print_message "Unknown option: $1" "$red"
            show_help
            exit 1
            ;;
    esac
done

# Check required parameters
if [ -z "$SERVER_URL" ]; then
    print_message "Error: RTMP server URL is required" "$red"
    show_help
    exit 1
fi

# Full RTMP URL
RTMP_URL="${SERVER_URL}/${STREAM_KEY}"

# Check for FFmpeg
if ! command -v ffmpeg &> /dev/null; then
    print_message "Error: FFmpeg is not installed. Please install it first." "$red"
    exit 1
fi

# Print stream information
print_message "Stream Configuration:" "$blue"
echo "RTMP URL: $RTMP_URL"
echo "Video Bitrate: $VIDEO_BITRATE"
echo "Audio Bitrate: $AUDIO_BITRATE"
echo "Preset: $PRESET"
echo ""

# Construct FFmpeg command based on input type
if [ "$USE_WEBCAM" = true ]; then
    # Detect OS for webcam streaming
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux webcam
        WEBCAM_CMD="-f v4l2 -framerate 30 -video_size 1280x720 -i /dev/video0 -f alsa -i hw:0"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS webcam
        WEBCAM_CMD="-f avfoundation -framerate 30 -i \"0:0\""
    elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
        # Windows webcam
        WEBCAM_CMD="-f dshow -i video=\"Integrated Camera\":audio=\"Microphone\""
    else
        print_message "Unsupported OS for webcam detection. Using Linux defaults." "$yellow"
        WEBCAM_CMD="-f v4l2 -framerate 30 -video_size 1280x720 -i /dev/video0"
    fi
    
    print_message "Streaming from webcam..." "$green"
    COMMAND="ffmpeg $WEBCAM_CMD -c:v libx264 -preset $PRESET -b:v $VIDEO_BITRATE -c:a aac -b:a $AUDIO_BITRATE -f flv \"$RTMP_URL\""
    
elif [ "$USE_DESKTOP" = true ]; then
    # Detect OS for desktop streaming
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux desktop
        DESKTOP_CMD="-f x11grab -framerate 30 -video_size 1920x1080 -i :0.0 -f pulse -i default"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS desktop
        DESKTOP_CMD="-f avfoundation -framerate 30 -i \"1:0\""
    elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
        # Windows desktop
        DESKTOP_CMD="-f gdigrab -framerate 30 -i desktop -f dshow -i audio=\"Microphone\""
    else
        print_message "Unsupported OS for desktop capture. Using Linux defaults." "$yellow"
        DESKTOP_CMD="-f x11grab -framerate 30 -video_size 1920x1080 -i :0.0"
    fi
    
    print_message "Streaming desktop..." "$green"
    COMMAND="ffmpeg $DESKTOP_CMD -c:v libx264 -preset $PRESET -b:v $VIDEO_BITRATE -c:a aac -b:a $AUDIO_BITRATE -f flv \"$RTMP_URL\""
    
else
    # File streaming
    if [ -z "$INPUT_FILE" ]; then
        print_message "Error: Input file is required when not using webcam or desktop capture" "$red"
        show_help
        exit 1
    fi
    
    if [ ! -f "$INPUT_FILE" ]; then
        print_message "Error: Input file not found: $INPUT_FILE" "$red"
        exit 1
    fi
    
    print_message "Streaming file: $INPUT_FILE" "$green"
    COMMAND="ffmpeg $LOOP -re -i \"$INPUT_FILE\" -c:v libx264 -preset $PRESET -b:v $VIDEO_BITRATE -c:a aac -b:a $AUDIO_BITRATE -f flv \"$RTMP_URL\""
fi

# Print the command
print_message "Executing command:" "$yellow"
echo "$COMMAND"
echo ""

# Execute the command
print_message "Starting stream... Press Ctrl+C to stop." "$green"
echo ""
eval "$COMMAND"