#!/bin/bash

# Development startup script for RTMP Stream Viewer
# This script starts the application using Flask development server

# Exit on error
set -e

# Get parameters with default values
PORT=${PORT:-5000}
HOST=${HOST:-0.0.0.0}

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    echo "Activating virtual environment..."
    source venv/bin/activate
fi

# Set environment to development
export FLASK_ENV=development

# Start the application
echo "Starting application in development mode on ${HOST}:${PORT}..."
python run.py --host ${HOST} --port ${PORT} --debug