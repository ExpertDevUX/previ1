#!/bin/bash

# Minimal fix for the rtmp_stat directive issue
# This script makes the absolute minimum changes needed to fix the error

# Domain name
DOMAIN="hwosecurity.org"

echo "Creating backup of domain configuration..."
if [ -f "/etc/nginx/sites-available/$DOMAIN.conf" ]; then
    cp "/etc/nginx/sites-available/$DOMAIN.conf" "/etc/nginx/sites-available/$DOMAIN.conf.backup"
fi

echo "Fixing rtmp_stat directive issue..."

# Remove the rtmp_stat directives from the domain configuration
sed -i '/rtmp_stat all/d' "/etc/nginx/sites-available/$DOMAIN.conf"
sed -i '/rtmp_stat_stylesheet/d' "/etc/nginx/sites-available/$DOMAIN.conf"

echo "Testing NGINX configuration..."
nginx -t

echo "If the configuration test passed, reload NGINX with:"
echo "  sudo systemctl reload nginx"

echo "Done."