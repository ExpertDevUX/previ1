#!/bin/bash

# Generate a test video for RTMP streaming
# This script creates a short MP4 file with a test pattern and audio tone
# Useful for testing streaming without needing an actual video file

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Default settings
DURATION=10
WIDTH=1280
HEIGHT=720
FRAMERATE=30
OUTPUT_FILE="test_video.mp4"
PATTERN="testsrc"

# Available test patterns
PATTERNS=("testsrc" "testsrc2" "smptebars" "mandelbrot" "rgbtestsrc" "sierpinski" "yuvtestsrc")

# Function to display help
show_help() {
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  -d, --duration SECONDS  Duration in seconds (default: 10)"
    echo "  -w, --width PIXELS      Width in pixels (default: 1280)"
    echo "  -h, --height PIXELS     Height in pixels (default: 720)"
    echo "  -r, --framerate FPS     Framerate (default: 30)"
    echo "  -o, --output FILE       Output filename (default: test_video.mp4)"
    echo "  -p, --pattern NAME      Test pattern (default: testsrc)"
    echo "  -l, --list-patterns     List available test patterns"
    echo "  --help                  Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0"
    echo "  $0 -d 30 -w 1920 -h 1080 -r 60 -o my_test.mp4"
    echo "  $0 -p mandelbrot -d 20"
    echo ""
}

# List available patterns
list_patterns() {
    echo "Available test patterns:"
    for pattern in "${PATTERNS[@]}"; do
        echo "  - $pattern"
    done
    echo ""
    echo "Example usage:"
    echo "  $0 -p mandelbrot"
    echo ""
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -d|--duration)
            DURATION="$2"
            shift
            shift
            ;;
        -w|--width)
            WIDTH="$2"
            shift
            shift
            ;;
        -h|--height)
            HEIGHT="$2"
            shift
            shift
            ;;
        -r|--framerate)
            FRAMERATE="$2"
            shift
            shift
            ;;
        -o|--output)
            OUTPUT_FILE="$2"
            shift
            shift
            ;;
        -p|--pattern)
            PATTERN="$2"
            shift
            shift
            ;;
        -l|--list-patterns)
            list_patterns
            exit 0
            ;;
        --help)
            show_help
            exit 0
            ;;
        *)
            print_message "Unknown option: $1" "$red"
            show_help
            exit 1
            ;;
    esac
done

# Check for FFmpeg
if ! command -v ffmpeg &> /dev/null; then
    print_message "Error: FFmpeg is not installed. Please install it first." "$red"
    exit 1
fi

# Validate pattern
valid_pattern=0
for p in "${PATTERNS[@]}"; do
    if [ "$p" == "$PATTERN" ]; then
        valid_pattern=1
        break
    fi
done

if [ $valid_pattern -eq 0 ]; then
    print_message "Error: Invalid pattern '$PATTERN'" "$red"
    list_patterns
    exit 1
fi

# Print settings
print_message "Test Video Generator" "$blue"
echo "Pattern: $PATTERN"
echo "Duration: $DURATION seconds"
echo "Resolution: ${WIDTH}x${HEIGHT}"
echo "Framerate: $FRAMERATE fps"
echo "Output file: $OUTPUT_FILE"
echo ""

# Generate command
print_message "Generating test video..." "$green"
ffmpeg -y -f lavfi -i "$PATTERN=size=${WIDTH}x${HEIGHT}:rate=$FRAMERATE" \
    -f lavfi -i "sine=frequency=1000:sample_rate=44100" \
    -c:v libx264 -preset fast -crf 22 \
    -c:a aac -b:a 128k \
    -t $DURATION \
    "$OUTPUT_FILE"

# Check if file was created
if [ -f "$OUTPUT_FILE" ]; then
    file_size=$(du -h "$OUTPUT_FILE" | cut -f1)
    print_message "Test video created successfully: $OUTPUT_FILE ($file_size)" "$green"
    echo ""
    print_message "To stream this video to your RTMP server:" "$yellow"
    echo "ffmpeg -re -i $OUTPUT_FILE -c:v copy -c:a copy -f flv rtmp://your-server-ip/live/stream-key"
    echo ""
    print_message "Or use the stream_with_ffmpeg.sh script:" "$yellow"
    echo "./stream_with_ffmpeg.sh -i $OUTPUT_FILE -s rtmp://your-server-ip/live -k stream-key"
else
    print_message "Error: Failed to create test video" "$red"
fi