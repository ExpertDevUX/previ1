# FFmpeg Streaming Guide

This guide provides examples of how to use FFmpeg to stream content to your RTMP server.

## Basic FFmpeg Streaming Commands

### Stream a Video File to RTMP Server

```bash
ffmpeg -re -i input_video.mp4 -c:v libx264 -preset veryfast -b:v 1500k -maxrate 1500k -bufsize 3000k \
-c:a aac -b:a 128k -ac 2 -ar 44100 \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-re`: Read the input at native frame rate (simulates real-time streaming)
- `-i input_video.mp4`: Input video file
- `-c:v libx264`: Use H.264 video codec
- `-preset veryfast`: Encoding preset (options: ultrafast, superfast, veryfast, faster, fast, medium, slow, slower, veryslow)
- `-b:v 1500k`: Video bitrate
- `-maxrate 1500k -bufsize 3000k`: Limits the maximum bitrate
- `-c:a aac`: Use AAC audio codec
- `-b:a 128k`: Audio bitrate
- `-ac 2`: Audio channels (stereo)
- `-ar 44100`: Audio sample rate (Hz)
- `-f flv`: Output format
- `rtmp://your-server-ip/live/stream-key`: RTMP destination URL

### Stream from a Webcam

```bash
ffmpeg -f v4l2 -framerate 30 -video_size 1280x720 -input_format mjpeg -i /dev/video0 \
-f alsa -i hw:0 -c:v libx264 -preset ultrafast -tune zerolatency \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-f v4l2`: Use Video4Linux2 input format (for webcams on Linux)
- `-framerate 30`: Capture at 30 FPS
- `-video_size 1280x720`: Capture resolution
- `-input_format mjpeg`: Input format (common for webcams)
- `-i /dev/video0`: Webcam device
- `-f alsa -i hw:0`: Audio source (sound card)
- `-tune zerolatency`: Optimize for minimal latency

### Stream Desktop Screen (Linux)

```bash
ffmpeg -f x11grab -framerate 30 -video_size 1920x1080 -i :0.0 \
-f pulse -i default -c:v libx264 -preset ultrafast -b:v 1500k \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-f x11grab`: X11 display grabbing (for Linux desktop)
- `-video_size 1920x1080`: Screen resolution to capture
- `-i :0.0`: X11 display
- `-f pulse -i default`: PulseAudio input (system sound)

### Stream Desktop Screen (macOS)

```bash
ffmpeg -f avfoundation -framerate 30 -i "1:0" -c:v libx264 -preset ultrafast -b:v 1500k \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-f avfoundation`: macOS AVFoundation input
- `-i "1:0"`: "1" is screen index, "0" is audio device index

### Stream Desktop Screen (Windows)

```bash
ffmpeg -f gdigrab -framerate 30 -i desktop -f dshow -i audio="Microphone (Realtek High Definition Audio)" \
-c:v libx264 -preset ultrafast -b:v 1500k \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-f gdigrab`: Windows GDI-based screen capture
- `-i desktop`: Capture entire desktop
- `-f dshow`: DirectShow input format (for audio)
- `-i audio="Microphone (Realtek High Definition Audio)"`: Audio device (change to match your system)

## Advanced FFmpeg Streaming Examples

### Stream with Video Overlay/Watermark

```bash
ffmpeg -re -i input_video.mp4 -i logo.png -filter_complex "overlay=10:10" \
-c:v libx264 -preset veryfast -b:v 1500k \
-c:a copy \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-i logo.png`: Logo/watermark image
- `-filter_complex "overlay=10:10"`: Position the logo at x=10, y=10 from top-left
- `-c:a copy`: Copy audio stream without re-encoding

### Stream with Text Overlay

```bash
ffmpeg -re -i input_video.mp4 \
-vf "drawtext=text='Live Stream':fontcolor=white:fontsize=24:box=1:boxcolor=black@0.5:boxborderw=5:x=10:y=10" \
-c:v libx264 -preset veryfast -b:v 1500k \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-vf "drawtext=..."`: Video filter to add text overlay
- `fontcolor=white:fontsize=24`: Text appearance
- `box=1:boxcolor=black@0.5`: Text background box with transparency
- `x=10:y=10`: Position from top-left

### Stream with Multiple Output Qualities

```bash
ffmpeg -re -i input_video.mp4 \
-c:v libx264 -preset veryfast -b:v 3000k -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/high \
-c:v libx264 -preset veryfast -b:v 1500k -c:a aac -b:a 128k -f flv rtmp://your-server-ip/live/medium \
-c:v libx264 -preset veryfast -b:v 750k -c:a aac -b:a 96k -f flv rtmp://your-server-ip/live/low
```

Explanation:
- Stream the same content in three different qualities
- Each quality uses a different stream key: high, medium, low

### Stream Online Video (RTSP Camera, for example)

```bash
ffmpeg -re -i rtsp://camera_ip:554/stream -c:v libx264 -preset veryfast -b:v 1500k \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-i rtsp://camera_ip:554/stream`: RTSP camera stream URL

### Stream with Hardware Acceleration (NVIDIA GPU)

```bash
ffmpeg -re -i input_video.mp4 -c:v h264_nvenc -preset llhp -b:v 1500k \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-c:v h264_nvenc`: NVIDIA hardware encoding
- `-preset llhp`: Low latency high performance preset

### Create a Continuous Stream Loop

```bash
ffmpeg -stream_loop -1 -re -i input_video.mp4 -c:v libx264 -preset veryfast -b:v 1500k \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Explanation:
- `-stream_loop -1`: Loop the input file indefinitely (-1 means infinite loop)

### Create a Stream from Multiple Input Files

```bash
ffmpeg -re -f concat -safe 0 -i playlist.txt -c:v libx264 -preset veryfast -b:v 1500k \
-c:a aac -b:a 128k \
-f flv rtmp://your-server-ip/live/stream-key
```

Create a playlist.txt file:
```
file 'video1.mp4'
file 'video2.mp4'
file 'video3.mp4'
```

Explanation:
- `-f concat`: Concatenate multiple input files
- `-safe 0`: Allow files with absolute paths
- `-i playlist.txt`: Input file containing the list of videos

## Checking Stream Status

### Check if Your Stream is Working

```bash
ffprobe -v error -show_entries stream rtmp://your-server-ip/live/stream-key
```

## Tips for Better Streaming

1. **Network Bandwidth**: Ensure your upload bandwidth is at least 1.5 times your video bitrate.

2. **Hardware Acceleration**: Use hardware acceleration when available (`h264_nvenc` for NVIDIA GPUs, `h264_amf` for AMD, `h264_qsv` for Intel).

3. **Keyframe Interval**: For better compatibility with HLS, set keyframe interval to 2 seconds:
   ```
   -g 60 (for 30fps video)
   ```

4. **Audio-Video Sync**: If you have sync issues, try adding:
   ```
   -vsync 1
   ```

5. **Buffer Size**: Increase buffer size for more stable streaming on unstable connections:
   ```
   -bufsize 6000k
   ```

6. **Adaptive Bitrate**: Let FFmpeg adapt to your network conditions:
   ```
   -maxrate 1500k -bufsize 3000k
   ```

7. **Testing**: Always test your FFmpeg command locally before streaming to a live server.

## Troubleshooting

- **Error: Connection refused**: Check if your RTMP server is running and port 1935 is open.
- **Error: Stream not found**: Make sure your application name ('live') is correctly configured in nginx.conf.
- **High CPU usage**: Use a faster preset or hardware acceleration.
- **Choppy video**: Lower your bitrate or resolution.

## Additional Resources

- [FFmpeg Documentation](https://ffmpeg.org/documentation.html)
- [FFmpeg Wiki](https://trac.ffmpeg.org/wiki)
- [FFmpeg Encoding Guide](https://trac.ffmpeg.org/wiki/Encode/H.264)