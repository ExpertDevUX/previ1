#!/bin/bash

# SSL Installation Script for RTMP Stream Viewer
# This script provides multiple methods to install SSL certificates

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    print_message "This script must be run as root. Try using sudo." "$red"
    exit 1
fi

# Domain name to configure (default or specified by user)
DOMAIN=${1:-"hwosecurity.org"}
EMAIL=${2:-"admin@$DOMAIN"}

print_message "SSL Certificate Installation" "$blue"
print_message "==========================" "$blue"
echo ""
print_message "Installing SSL for domain: $DOMAIN" "$yellow"
print_message "Using email: $EMAIL" "$yellow"
echo ""

# Check if NGINX is installed
if ! command -v nginx &> /dev/null; then
    print_message "NGINX is not installed. Please run install_nginx_rtmp.sh first." "$red"
    exit 1
fi

# Path to the site configuration
CONF_PATH="/etc/nginx/sites-available/$DOMAIN.conf"
if [ ! -f "$CONF_PATH" ]; then
    print_message "Configuration file not found at $CONF_PATH" "$red"
    print_message "Checking if it exists in the current directory..." "$yellow"
    
    if [ -f "$DOMAIN.conf" ]; then
        CONF_PATH="$DOMAIN.conf"
        print_message "Using $CONF_PATH from current directory" "$green"
    else
        print_message "No configuration file found. Please run domain_setup.sh first." "$red"
        exit 1
    fi
fi

# Backup the configuration
BACKUP_PATH="${CONF_PATH}.backup.$(date +%Y%m%d%H%M%S)"
cp "$CONF_PATH" "$BACKUP_PATH"
print_message "Backup created at $BACKUP_PATH" "$green"

# Display menu for SSL installation methods
print_message "Please select an SSL installation method:" "$yellow"
echo "1) Certbot with Let's Encrypt (Automatic)"
echo "2) Self-signed certificate (For testing)"
echo "3) Manual certificate installation (Bring your own certificates)"
echo "4) Cloudflare Origin Certificate"
read -p "Enter your choice [1-4]: " ssl_method

case $ssl_method in
    1)
        # Let's Encrypt with Certbot
        print_message "Installing Certbot..." "$green"
        if command -v apt-get &> /dev/null; then
            apt-get update
            apt-get install -y certbot python3-certbot-nginx
        elif command -v yum &> /dev/null; then
            yum install -y certbot python3-certbot-nginx
        else
            print_message "Package manager not found. Please install Certbot manually." "$red"
            exit 1
        fi
        
        print_message "Obtaining SSL certificate from Let's Encrypt..." "$green"
        certbot --nginx -d $DOMAIN -d www.$DOMAIN --email $EMAIL --agree-tos --non-interactive
        
        print_message "Let's Encrypt certificate installed successfully!" "$green"
        print_message "Certificates will auto-renew with the Certbot timer service." "$yellow"
        ;;
        
    2)
        # Self-signed certificate
        print_message "Generating self-signed certificate..." "$green"
        
        # Create directory for certificates
        mkdir -p /etc/nginx/ssl/$DOMAIN
        
        # Generate self-signed certificate
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout /etc/nginx/ssl/$DOMAIN/privkey.pem \
            -out /etc/nginx/ssl/$DOMAIN/fullchain.pem \
            -subj "/C=US/ST=State/L=City/O=Organization/CN=$DOMAIN"
        
        # Update NGINX configuration
        cat > $CONF_PATH << EOF
# NGINX configuration for $DOMAIN with self-signed SSL
# RTMP, HLS, and DASH streaming

# HTTP server (redirect to HTTPS)
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    
    # Redirect HTTP to HTTPS
    return 301 https://\$host\$request_uri;
}

# HTTPS server
server {
    listen 443 ssl;
    server_name $DOMAIN www.$DOMAIN;
    
    # SSL configuration
    ssl_certificate /etc/nginx/ssl/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/$DOMAIN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    
    # Web application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # HLS streaming location
    location /hls {
        # Serve HLS fragments
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # DASH streaming location
    location /dash {
        # Serve DASH fragments
        types {
            application/dash+xml mpd;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # Simple stats page
    location /stats {
        # Stats displayed using HTTP
        root /var/www/stream;
        add_header Refresh "5; \$request_uri";
    }
    
    location /stat.xsl {
        root /etc/nginx/;
    }
    
    # Logging configuration
    access_log /var/log/nginx/$DOMAIN-access.log;
    error_log /var/log/nginx/$DOMAIN-error.log;
}
EOF
        
        print_message "Self-signed certificate installed successfully!" "$green"
        print_message "Warning: Browsers will show a security warning for self-signed certificates." "$yellow"
        ;;
        
    3)
        # Manual certificate installation
        print_message "Manual certificate installation" "$green"
        
        # Ask for certificate paths
        read -p "Enter the path to your SSL certificate file: " ssl_cert
        read -p "Enter the path to your SSL private key file: " ssl_key
        
        if [ ! -f "$ssl_cert" ] || [ ! -f "$ssl_key" ]; then
            print_message "Certificate files not found. Please check the paths and try again." "$red"
            exit 1
        fi
        
        # Create directory for certificates
        mkdir -p /etc/nginx/ssl/$DOMAIN
        
        # Copy certificates to NGINX directory
        cp "$ssl_cert" /etc/nginx/ssl/$DOMAIN/fullchain.pem
        cp "$ssl_key" /etc/nginx/ssl/$DOMAIN/privkey.pem
        
        # Update NGINX configuration
        cat > $CONF_PATH << EOF
# NGINX configuration for $DOMAIN with manual SSL
# RTMP, HLS, and DASH streaming

# HTTP server (redirect to HTTPS)
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    
    # Redirect HTTP to HTTPS
    return 301 https://\$host\$request_uri;
}

# HTTPS server
server {
    listen 443 ssl;
    server_name $DOMAIN www.$DOMAIN;
    
    # SSL configuration
    ssl_certificate /etc/nginx/ssl/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/$DOMAIN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    
    # Web application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # HLS streaming location
    location /hls {
        # Serve HLS fragments
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # DASH streaming location
    location /dash {
        # Serve DASH fragments
        types {
            application/dash+xml mpd;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # Simple stats page
    location /stats {
        # Stats displayed using HTTP
        root /var/www/stream;
        add_header Refresh "5; \$request_uri";
    }
    
    location /stat.xsl {
        root /etc/nginx/;
    }
    
    # Logging configuration
    access_log /var/log/nginx/$DOMAIN-access.log;
    error_log /var/log/nginx/$DOMAIN-error.log;
}
EOF
        
        print_message "Manual certificates installed successfully!" "$green"
        ;;
        
    4)
        # Cloudflare Origin Certificate
        print_message "Cloudflare Origin Certificate Setup" "$green"
        print_message "You need to generate an Origin Certificate in your Cloudflare dashboard first." "$yellow"
        print_message "Go to: SSL/TLS > Origin Server > Create Certificate" "$yellow"
        echo ""
        
        # Ask for certificate content
        print_message "Please paste your Cloudflare Origin Certificate (CTRL+D when done):" "$yellow"
        ssl_cert_content=$(cat)
        
        print_message "Please paste your Cloudflare Origin Private Key (CTRL+D when done):" "$yellow"
        ssl_key_content=$(cat)
        
        # Create directory for certificates
        mkdir -p /etc/nginx/ssl/$DOMAIN
        
        # Save certificates
        echo "$ssl_cert_content" > /etc/nginx/ssl/$DOMAIN/cloudflare.pem
        echo "$ssl_key_content" > /etc/nginx/ssl/$DOMAIN/cloudflare.key
        
        # Update NGINX configuration
        cat > $CONF_PATH << EOF
# NGINX configuration for $DOMAIN with Cloudflare Origin Certificate
# RTMP, HLS, and DASH streaming

# HTTP server (redirect to HTTPS)
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    
    # Redirect HTTP to HTTPS
    return 301 https://\$host\$request_uri;
}

# HTTPS server
server {
    listen 443 ssl;
    server_name $DOMAIN www.$DOMAIN;
    
    # SSL configuration
    ssl_certificate /etc/nginx/ssl/$DOMAIN/cloudflare.pem;
    ssl_certificate_key /etc/nginx/ssl/$DOMAIN/cloudflare.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    
    # Web application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # HLS streaming location
    location /hls {
        # Serve HLS fragments
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # DASH streaming location
    location /dash {
        # Serve DASH fragments
        types {
            application/dash+xml mpd;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # Simple stats page
    location /stats {
        # Stats displayed using HTTP
        root /var/www/stream;
        add_header Refresh "5; \$request_uri";
    }
    
    location /stat.xsl {
        root /etc/nginx/;
    }
    
    # Logging configuration
    access_log /var/log/nginx/$DOMAIN-access.log;
    error_log /var/log/nginx/$DOMAIN-error.log;
}
EOF
        
        print_message "Cloudflare Origin Certificate installed successfully!" "$green"
        print_message "Make sure your Cloudflare SSL/TLS mode is set to 'Full (strict)'." "$yellow"
        ;;
        
    *)
        print_message "Invalid choice. Exiting." "$red"
        exit 1
        ;;
esac

# Test NGINX configuration
print_message "Testing NGINX configuration..." "$green"
nginx -t

if [ $? -eq 0 ]; then
    # Reload NGINX
    print_message "Reloading NGINX..." "$green"
    systemctl reload nginx
    
    print_message "SSL configuration completed successfully!" "$green"
    echo ""
    print_message "Your secure streaming URLs:" "$yellow"
    echo "RTMP: rtmp://$DOMAIN/live/stream-key"
    echo "HLS: https://$DOMAIN/hls/stream-key.m3u8"
    echo "DASH: https://$DOMAIN/dash/stream-key.mpd"
    echo ""
    print_message "Web Application:" "$yellow"
    echo "https://$DOMAIN/"
    echo ""
    print_message "Stream Statistics:" "$yellow"
    echo "https://$DOMAIN/stats"
    echo ""
else
    print_message "Configuration test failed." "$red"
    print_message "Restoring backup..." "$yellow"
    cp "$BACKUP_PATH" "$CONF_PATH"
    print_message "Original configuration restored from backup." "$green"
    print_message "Please check for errors and try again." "$red"
    exit 1
fi