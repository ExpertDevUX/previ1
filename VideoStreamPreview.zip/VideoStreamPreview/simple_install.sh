#!/bin/bash

# Simple installation script for hwosecurity.org
# This script uses a minimal configuration without problematic directives

# Exit on error
set -e

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root. Try using sudo."
    exit 1
fi

# Domain name
DOMAIN="hwosecurity.org"

echo "Setting up hwosecurity.org with minimal configuration..."

# Backup any existing configuration
if [ -f "/etc/nginx/sites-available/$DOMAIN.conf" ]; then
    echo "Backing up existing configuration..."
    cp "/etc/nginx/sites-available/$DOMAIN.conf" "/etc/nginx/sites-available/$DOMAIN.conf.backup.$(date +%s)"
fi

# Create stream directories
echo "Creating stream directories..."
mkdir -p /var/www/stream/hls
mkdir -p /var/www/stream/dash
chmod 755 -R /var/www/stream
chown -R www-data:www-data /var/www/stream

# Create a simple stats HTML file
echo "Creating a simple stats page..."
cat > /var/www/stream/stats.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Stream Status</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="5">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        h1 {
            color: #444;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .status {
            margin: 20px 0;
            padding: 15px;
            border-radius: 4px;
        }
        .online {
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
            color: #3c763d;
        }
        .offline {
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            color: #a94442;
        }
        .refresh {
            color: #666;
            font-size: 0.8em;
            text-align: right;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>RTMP Stream Status for hwosecurity.org</h1>
        
        <div class="status offline">
            <h3>Stream Status: Offline</h3>
            <p>No active streams found. This page checks the server status every 5 seconds.</p>
        </div>
        
        <div>
            <h3>Streaming Information</h3>
            <p>To stream to this server:</p>
            <ul>
                <li><strong>RTMP URL:</strong> rtmp://hwosecurity.org/live</li>
                <li><strong>Stream Key:</strong> your-stream-key</li>
            </ul>
            
            <p>To watch the stream:</p>
            <ul>
                <li><strong>HLS:</strong> https://hwosecurity.org/hls/your-stream-key.m3u8</li>
                <li><strong>DASH:</strong> https://hwosecurity.org/dash/your-stream-key.mpd</li>
            </ul>
        </div>
        
        <p class="refresh">This page refreshes automatically every 5 seconds.</p>
    </div>
</body>
</html>
EOF

# Copy the simplified configuration
echo "Installing simplified NGINX configuration..."
cp hwosecurity.org.simple.conf /etc/nginx/sites-available/$DOMAIN.conf

# Enable the site if it's not already enabled
if [ ! -L "/etc/nginx/sites-enabled/$DOMAIN.conf" ]; then
    echo "Enabling site configuration..."
    ln -sf /etc/nginx/sites-available/$DOMAIN.conf /etc/nginx/sites-enabled/
fi

# Make sure the include directive for sites-enabled exists in nginx.conf
if ! grep -q "include /etc/nginx/sites-enabled/\*.conf;" /etc/nginx/nginx.conf; then
    echo "Adding sites-enabled include to nginx.conf..."
    sed -i '/http {/a \    include /etc/nginx/sites-enabled/*.conf;' /etc/nginx/nginx.conf
fi

# Test the configuration
echo "Testing NGINX configuration..."
if nginx -t; then
    echo "Configuration is valid. Reloading NGINX..."
    systemctl reload nginx
    echo "Installation completed successfully!"
    echo ""
    echo "Your streaming URLs:"
    echo "RTMP: rtmp://$DOMAIN/live/stream-key"
    echo "HLS: http://$DOMAIN/hls/stream-key.m3u8"
    echo "DASH: http://$DOMAIN/dash/stream-key.mpd"
    echo ""
    echo "Web Application:"
    echo "http://$DOMAIN/"
    echo ""
    echo "Simple Stream Status:"
    echo "http://$DOMAIN/stats"
else
    echo "Configuration test failed. Check the errors above."
    exit 1
fi