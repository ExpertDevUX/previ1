# NGINX RTMP Server Setup Guide

This guide explains how to set up a complete RTMP streaming server with NGINX and integrate it with the Stream Viewer application.

## Table of Contents

1. [Automatic Installation](#automatic-installation)
2. [Manual Installation](#manual-installation)
3. [Configuration](#configuration)
4. [Test Your Setup](#test-your-setup)
5. [Integration with Stream Viewer](#integration-with-stream-viewer)
6. [Advanced Configuration](#advanced-configuration)
7. [Troubleshooting](#troubleshooting)

## Automatic Installation

For a quick setup, we've provided an automated installation script that will install and configure NGINX with the RTMP module on most Debian-based Linux distributions.

1. Make the installation script executable:
   ```bash
   chmod +x install_nginx_rtmp.sh
   ```

2. Run the script with sudo:
   ```bash
   sudo ./install_nginx_rtmp.sh
   ```

3. The script will:
   - Install required dependencies
   - Download and compile NGINX with the RTMP module
   - Configure NGINX for RTMP, HLS, and DASH streaming
   - Set up a systemd service for NGINX
   - Create the required directory structure
   - Generate configuration files and example pages

4. After installation, verify that NGINX is running:
   ```bash
   systemctl status nginx
   ```

## Manual Installation

If you prefer to install manually or the automatic script doesn't work for your system, follow these steps:

### 1. Install Dependencies

```bash
sudo apt-get update
sudo apt-get install -y build-essential libpcre3-dev libssl-dev zlib1g-dev wget git
```

### 2. Download NGINX and RTMP Module

```bash
# Create a temporary directory
mkdir -p ~/nginx-build && cd ~/nginx-build

# Download NGINX (check for the latest version)
wget https://nginx.org/download/nginx-1.24.0.tar.gz
tar -xf nginx-1.24.0.tar.gz

# Clone the RTMP module repository
git clone https://github.com/arut/nginx-rtmp-module.git
```

### 3. Compile and Install NGINX with RTMP Module

```bash
cd nginx-1.24.0

# Configure NGINX with RTMP module
./configure \
    --prefix=/usr/local/nginx \
    --sbin-path=/usr/local/sbin/nginx \
    --conf-path=/etc/nginx/nginx.conf \
    --error-log-path=/var/log/nginx/error.log \
    --pid-path=/var/run/nginx.pid \
    --lock-path=/var/lock/nginx.lock \
    --http-log-path=/var/log/nginx/access.log \
    --http-client-body-temp-path=/var/cache/nginx/client_temp \
    --http-proxy-temp-path=/var/cache/nginx/proxy_temp \
    --http-fastcgi-temp-path=/var/cache/nginx/fastcgi_temp \
    --with-http_ssl_module \
    --with-http_v2_module \
    --with-http_flv_module \
    --with-http_mp4_module \
    --add-module=../nginx-rtmp-module

# Compile and install
make
sudo make install
```

### 4. Create Required Directories

```bash
sudo mkdir -p /var/cache/nginx
sudo mkdir -p /var/www/stream/hls
sudo mkdir -p /var/www/stream/dash
sudo mkdir -p /var/www/stream/recordings
sudo chmod 755 -R /var/www/stream
sudo chown -R www-data:www-data /var/www/stream
```

### 5. Create NGINX Configuration

Create the NGINX configuration file manually:

```bash
sudo nano /etc/nginx/nginx.conf
```

Copy the content from the [Configuration](#configuration) section and paste it into the editor. Save and exit.

### 6. Create a Systemd Service File

```bash
sudo nano /etc/systemd/system/nginx.service
```

Add the following content:

```
[Unit]
Description=NGINX with RTMP Server
After=network.target

[Service]
Type=forking
PIDFile=/var/run/nginx.pid
ExecStartPre=/usr/local/sbin/nginx -t
ExecStart=/usr/local/sbin/nginx
ExecReload=/usr/local/sbin/nginx -s reload
ExecStop=/usr/local/sbin/nginx -s stop
PrivateTmp=true

[Install]
WantedBy=multi-user.target
```

### 7. Start and Enable NGINX Service

```bash
sudo systemctl daemon-reload
sudo systemctl start nginx
sudo systemctl enable nginx
```

## Configuration

Here's the default NGINX configuration for RTMP, HLS, and DASH streaming:

```nginx
worker_processes auto;
rtmp_auto_push on;
events {
    worker_connections 1024;
}

# RTMP configuration
rtmp {
    server {
        listen 1935; # Standard RTMP port
        chunk_size 4000;
        
        # RTMP Application
        application live {
            live on;
            record off;
            
            # Enable HLS
            hls on;
            hls_path /var/www/stream/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # Enable DASH
            dash on;
            dash_path /var/www/stream/dash;
            dash_fragment 3;
            dash_playlist_length 60;
        }
    }
}

# HTTP configuration for accessing HLS and DASH streams
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile      on;
    keepalive_timeout  65;
    server_tokens off;
    
    # Enable CORS for better browser compatibility
    add_header Access-Control-Allow-Origin *;
    add_header Access-Control-Allow-Methods 'GET, HEAD, OPTIONS';
    
    # Compression settings
    gzip  on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # HTTP Server
    server {
        listen      80;
        server_name localhost;
        
        # HLS streaming location
        location /hls {
            # Serve HLS fragments
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
            root /var/www/stream;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        # DASH streaming location
        location /dash {
            # Serve DASH fragments
            types {
                application/dash+xml mpd;
            }
            root /var/www/stream;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        # Simple stats page
        location /stats {
            rtmp_stat all;
            rtmp_stat_stylesheet stat.xsl;
            add_header Refresh "5; $request_uri";
        }
        
        location /stat.xsl {
            root /etc/nginx/;
        }
        
        # Simple status page example
        location / {
            root /var/www/html;
            index index.html;
        }
    }
}
```

## Test Your Setup

### Publishing a Stream

You can use OBS Studio to publish a stream to your RTMP server:

1. Open OBS Studio
2. Go to Settings > Stream
3. Select "Custom" as the service
4. Set the Server to: `rtmp://your-server-ip/live`
5. Set the Stream Key to any name (e.g., `test`)
6. Click "Start Streaming"

### Viewing the Stream

Once you have published a stream, you can view it using:

1. **RTMP URL**: `rtmp://your-server-ip/live/test`
2. **HLS URL**: `http://your-server-ip/hls/test.m3u8`
3. **DASH URL**: `http://your-server-ip/dash/test.mpd`

## Integration with Stream Viewer

To integrate your RTMP server with the Stream Viewer application:

1. Make sure both the NGINX RTMP server and Stream Viewer application are running
2. In the Stream Viewer's URL input field, enter one of:
   - RTMP stream: `rtmp://your-server-ip/live/test`
   - HLS stream: `http://your-server-ip/hls/test.m3u8`
   - DASH stream: `http://your-server-ip/dash/test.mpd`

3. Click "Load Stream" to view the stream

## Advanced Configuration

### Authentication

To add basic authentication to your RTMP server:

1. Create an authentication endpoint in your Stream Viewer application
2. Update the NGINX configuration:

```nginx
application live {
    live on;
    
    # Add authentication
    on_publish http://localhost:5000/auth;
    
    # Rest of your configuration...
}
```

3. In your Flask application, add an authentication route:

```python
@app.route('/auth', methods=['POST'])
def auth():
    # Get stream key from request
    stream_key = request.form.get('name')
    
    # Check if valid
    if stream_key == 'your-secret-key':
        return '', 200
    else:
        return '', 403
```

### Recording Streams

To enable recording of all streams:

```nginx
application live {
    live on;
    
    # Enable recording
    record all;
    record_path /var/www/stream/recordings;
    record_unique on;
    
    # Rest of your configuration...
}
```

### Changing Stream Quality

To improve stream quality, adjust these parameters in the `nginx.conf` file:

```nginx
application live {
    live on;
    
    # Better quality settings
    hls_fragment 2;
    hls_playlist_length 30;
    
    # Rest of your configuration...
}
```

## Troubleshooting

### NGINX Won't Start

Check the NGINX error log:

```bash
sudo cat /var/log/nginx/error.log
```

Make sure all paths in the configuration exist and have the correct permissions:

```bash
sudo mkdir -p /var/cache/nginx
sudo mkdir -p /var/www/stream/hls
sudo mkdir -p /var/www/stream/dash
sudo chmod 755 -R /var/www/stream
sudo chown -R www-data:www-data /var/www/stream
```

### Can't Connect to RTMP Server

1. Check if NGINX is running:
   ```bash
   sudo systemctl status nginx
   ```

2. Check if port 1935 is open:
   ```bash
   sudo netstat -tulpn | grep :1935
   ```

3. Check firewall settings:
   ```bash
   sudo ufw status
   ```

4. If using a firewall, allow RTMP traffic:
   ```bash
   sudo ufw allow 1935/tcp
   sudo ufw allow 80/tcp
   ```

### HLS or DASH Streams Not Working

1. Check the MIME types in your NGINX configuration
2. Ensure the stream paths have correct permissions
3. Check browser console for CORS errors

For HLS streams, confirm these settings:

```nginx
location /hls {
    types {
        application/vnd.apple.mpegurl m3u8;
        video/mp2t ts;
    }
    root /var/www/stream;
    add_header Cache-Control no-cache;
    add_header Access-Control-Allow-Origin *;
}
```

### Stream Quality Issues

If the stream quality is poor:

1. Increase the bitrate in your streaming software (OBS)
2. Adjust HLS or DASH fragment sizes:
   ```nginx
   # For smoother playback
   hls_fragment 2;
   hls_playlist_length 30;
   ```

3. Check your server's CPU and network usage during streaming

---

For additional help, please consult the [NGINX RTMP module documentation](https://github.com/arut/nginx-rtmp-module) or visit our project's support channels.