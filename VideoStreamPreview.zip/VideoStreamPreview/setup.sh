#!/bin/bash

# RTMP Stream Viewer Setup Script
# This script sets up the RTMP Stream Viewer application with all dependencies
# Supports venv, FFmpeg tools, and NGINX RTMP server setup

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Print step
print_step() {
    echo ""
    print_message "STEP $1: $2" "$blue"
    echo ""
}

# Check Python version
check_python() {
    if command -v python3 &>/dev/null; then
        PYTHON_CMD="python3"
    elif command -v python &>/dev/null; then
        PYTHON_VERSION=$(python --version 2>&1 | awk '{print $2}')
        if [[ "$PYTHON_VERSION" =~ ^3\. ]]; then
            PYTHON_CMD="python"
        else
            print_message "Error: Python 3.x is required but Python 2.x is installed" "$red"
            exit 1
        fi
    else
        print_message "Error: Python 3.x is required but not installed" "$red"
        exit 1
    fi
    
    PYTHON_VERSION=$($PYTHON_CMD --version 2>&1 | awk '{print $2}')
    print_message "Found Python $PYTHON_VERSION" "$green"
}

# Check FFmpeg
check_ffmpeg() {
    if command -v ffmpeg &>/dev/null; then
        FFMPEG_VERSION=$(ffmpeg -version | head -n1 | awk '{print $3}')
        print_message "Found FFmpeg $FFMPEG_VERSION" "$green"
        FFMPEG_INSTALLED=true
    else
        print_message "FFmpeg is not installed. Streaming tools will have limited functionality." "$yellow"
        print_message "To install FFmpeg, run the command appropriate for your system:" "$yellow"
        echo "  Ubuntu/Debian: sudo apt-get install ffmpeg"
        echo "  CentOS/RHEL: sudo yum install ffmpeg"
        echo "  macOS: brew install ffmpeg"
        echo "  Windows: Download from https://ffmpeg.org/download.html"
        FFMPEG_INSTALLED=false
    fi
}

# Install Python virtual environment
create_venv() {
    # Check if venv directory already exists
    if [ -d "venv" ]; then
        print_message "Virtual environment already exists" "$yellow"
        
        # Ask user if they want to recreate it
        read -p "Do you want to recreate the virtual environment? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            print_message "Removing existing virtual environment..." "$yellow"
            rm -rf venv
        else
            print_message "Using existing virtual environment" "$green"
            return
        fi
    fi
    
    print_message "Creating Python virtual environment..." "$green"
    $PYTHON_CMD -m venv venv
    
    print_message "Virtual environment created successfully" "$green"
}

# Activate virtual environment
activate_venv() {
    print_message "Activating virtual environment..." "$green"
    source venv/bin/activate
    
    # Upgrade pip
    print_message "Upgrading pip..." "$green"
    pip install --upgrade pip
}

# Install dependencies
install_dependencies() {
    print_message "Installing Python dependencies..." "$green"
    pip install -e .
    
    print_message "Dependencies installed successfully" "$green"
}

# Create directories
create_directories() {
    print_message "Creating necessary directories..." "$green"
    
    mkdir -p templates
    mkdir -p static/css
    mkdir -p static/js
    mkdir -p static/img
    
    print_message "Directories created successfully" "$green"
}

# Check for required files
check_files() {
    REQUIRED_FILES=("wsgi.py" "main.py" "streamviewer/__init__.py")
    MISSING_FILES=()
    
    for file in "${REQUIRED_FILES[@]}"; do
        if [ ! -f "$file" ]; then
            MISSING_FILES+=("$file")
        fi
    done
    
    if [ ${#MISSING_FILES[@]} -gt 0 ]; then
        print_message "Error: The following required files are missing:" "$red"
        for file in "${MISSING_FILES[@]}"; do
            echo "  - $file"
        done
        exit 1
    fi
    
    print_message "All required files found" "$green"
}

# Check for streaming tools
check_streaming_tools() {
    STREAMING_TOOLS=("stream_with_ffmpeg.sh" "generate_test_video.sh" "install_nginx_rtmp.sh")
    TOOL_STATUS=true
    
    for tool in "${STREAMING_TOOLS[@]}"; do
        if [ ! -f "$tool" ]; then
            print_message "Warning: $tool not found!" "$yellow"
            TOOL_STATUS=false
        else
            # Make sure tool is executable
            chmod +x "$tool"
        fi
    done
    
    if [ "$TOOL_STATUS" = true ]; then
        print_message "All streaming tools found and set as executable" "$green"
    else
        print_message "Some streaming tools were not found. Functionality may be limited." "$yellow"
    fi
}

# Make scripts executable
make_scripts_executable() {
    print_message "Making scripts executable..." "$green"
    
    SCRIPTS=("start_dev.sh" "start_prod.sh" "run.py" "setup.sh")
    for script in "${SCRIPTS[@]}"; do
        if [ -f "$script" ]; then
            chmod +x "$script"
            echo "  Made $script executable"
        fi
    done
    
    print_message "Scripts are now executable" "$green"
}

# Set up NGINX RTMP server (optional)
setup_nginx_rtmp() {
    print_message "NGINX RTMP Server Setup" "$yellow"
    echo ""
    
    if [ ! -f "install_nginx_rtmp.sh" ]; then
        print_message "Error: install_nginx_rtmp.sh script not found!" "$red"
        return
    fi
    
    # Make sure script is executable
    chmod +x "install_nginx_rtmp.sh"
    
    # Ask user if they want to install NGINX RTMP
    read -p "Do you want to install the NGINX RTMP server? (y/n) " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if [ "$EUID" -ne 0 ]; then
            print_message "The NGINX RTMP installer requires root privileges." "$yellow"
            print_message "Please run the following command separately after this setup completes:" "$yellow"
            echo "  sudo ./install_nginx_rtmp.sh"
        else
            print_message "Running NGINX RTMP installer..." "$green"
            ./install_nginx_rtmp.sh
        fi
    else
        print_message "Skipping NGINX RTMP installation." "$yellow"
        print_message "You can install it later with:" "$yellow"
        echo "  sudo ./install_nginx_rtmp.sh"
    fi
}

# Generate a test video
generate_test_video() {
    if [ "$FFMPEG_INSTALLED" = true ] && [ -f "generate_test_video.sh" ]; then
        print_message "Test Video Generation" "$yellow"
        echo ""
        
        # Ask user if they want to generate a test video
        read -p "Do you want to generate a test video for streaming? (y/n) " -n 1 -r
        echo
        
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            print_message "Generating test video..." "$green"
            chmod +x "generate_test_video.sh"
            ./generate_test_video.sh -d 10 -o test_video.mp4
        else
            print_message "Skipping test video generation." "$yellow"
            print_message "You can generate one later with:" "$yellow"
            echo "  ./generate_test_video.sh -d 10 -o test_video.mp4"
        fi
    fi
}

# Print usage information
print_usage_info() {
    print_message "RTMP Stream Viewer - Usage Information" "$green"
    echo ""
    
    print_message "Running the application:" "$yellow"
    echo "  1. Activate the virtual environment:"
    echo "     source venv/bin/activate"
    echo ""
    echo "  2. Start in production mode:"
    echo "     ./start_prod.sh"
    echo ""
    echo "  3. Or start in development mode:"
    echo "     ./start_dev.sh"
    echo ""
    
    print_message "Streaming tools:" "$yellow"
    echo "  - Stream using FFmpeg:"
    echo "    ./stream_with_ffmpeg.sh -i video.mp4 -s rtmp://your-server-ip/live -k mystream"
    echo ""
    echo "  - Generate test video:"
    echo "    ./generate_test_video.sh -d 30 -o test_video.mp4"
    echo ""
    echo "  - Install NGINX RTMP server:"
    echo "    sudo ./install_nginx_rtmp.sh"
    echo ""
    
    print_message "Documentation:" "$yellow"
    echo "  - RTMP Server Guide: RTMP_SERVER_GUIDE.md"
    echo "  - FFmpeg Streaming Guide: FFMPEG_STREAMING_GUIDE.md"
    echo "  - FFmpeg Quick Reference: FFMPEG_QUICKREF.md"
    echo "  - Project README: README.md"
    echo ""
}

# Main setup process
main() {
    print_message "RTMP Stream Viewer Setup" "$green"
    print_message "=======================" "$green"
    echo ""
    
    # Step 1: Check Python version
    print_step "1" "Checking Python version"
    check_python
    
    # Step 2: Check FFmpeg
    print_step "2" "Checking FFmpeg"
    check_ffmpeg
    
    # Step 3: Check for required files
    print_step "3" "Checking for required files"
    check_files
    
    # Step 4: Create virtual environment
    print_step "4" "Setting up Python virtual environment"
    create_venv
    
    # Step 5: Activate virtual environment
    print_step "5" "Activating virtual environment"
    activate_venv
    
    # Step 6: Install dependencies
    print_step "6" "Installing dependencies"
    install_dependencies
    
    # Step 7: Create directories
    print_step "7" "Creating directories"
    create_directories
    
    # Step 8: Check streaming tools
    print_step "8" "Checking streaming tools"
    check_streaming_tools
    
    # Step 9: Make scripts executable
    print_step "9" "Making scripts executable"
    make_scripts_executable
    
    # Step 10: Generate test video
    print_step "10" "Generate test video"
    generate_test_video
    
    # Step 11: Setup NGINX RTMP (optional)
    print_step "11" "Setup NGINX RTMP server (optional)"
    setup_nginx_rtmp
    
    # Step 12: Setup complete
    print_step "12" "Setup complete"
    
    print_message "RTMP Stream Viewer has been set up successfully!" "$green"
    echo ""
    
    # Print usage information
    print_usage_info
    
    print_message "Thank you for installing RTMP Stream Viewer!" "$green"
}

# Run the main function
main

# If this script was sourced, keep the virtual environment activated
# If run directly, deactivate the virtual environment to avoid affecting the current shell
if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    print_message "Virtual environment is now active" "$green"
else
    deactivate 2>/dev/null || true
    print_message "Setup completed, you may now activate the virtual environment" "$green"
fi