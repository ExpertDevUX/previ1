# Domain Setup Guide for RTMP Streaming Server

This guide explains how to configure your NGINX RTMP server to work with your domain (hwosecurity.org) for streaming services.

## Prerequisites

1. A registered domain (hwosecurity.org)
2. DNS records pointing to your server's IP address
3. NGINX with RTMP module installed (using install_nginx_rtmp.sh)
4. Access to your server with root/sudo privileges

## Quick Setup with Script

For a quick setup, we've provided an automated script that will configure NGINX for your domain:

1. Make the domain setup script executable:
   ```bash
   chmod +x domain_setup.sh
   ```

2. Run the script with sudo:
   ```bash
   sudo ./domain_setup.sh hwosecurity.org
   ```

3. The script will:
   - Create a domain-specific NGINX configuration
   - Set up paths for HLS and DASH streaming
   - Configure HTTP and HTTPS (initially with HTTP only)
   - Test and reload the NGINX configuration

## Manual Setup

If you prefer to set up manually or need more customization, follow these steps:

### 1. Create NGINX Site Configuration

Create a new file at `/etc/nginx/sites-available/hwosecurity.org.conf` with the following content:

```nginx
# NGINX configuration for hwosecurity.org
# RTMP, HLS, and DASH streaming

# HTTP Server for HLS/DASH and Web UI
server {
    listen 80;
    server_name hwosecurity.org www.hwosecurity.org;
    
    # Redirect all HTTP traffic to HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name hwosecurity.org www.hwosecurity.org;
    
    # SSL configuration
    # Uncomment these lines once you have SSL certificates
    # ssl_certificate /etc/letsencrypt/live/hwosecurity.org/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/hwosecurity.org/privkey.pem;
    # ssl_protocols TLSv1.2 TLSv1.3;
    # ssl_prefer_server_ciphers on;
    
    # For now, since SSL is commented out, allow HTTP
    ssl off;
    
    # Web application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # HLS streaming location
    location /hls {
        # Serve HLS fragments
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # DASH streaming location
    location /dash {
        # Serve DASH fragments
        types {
            application/dash+xml mpd;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # Simple stats page
    location /stats {
        rtmp_stat all;
        rtmp_stat_stylesheet stat.xsl;
        add_header Refresh "5; $request_uri";
    }
    
    location /stat.xsl {
        root /etc/nginx/;
    }
    
    # Logging configuration
    access_log /var/log/nginx/hwosecurity.org-access.log;
    error_log /var/log/nginx/hwosecurity.org-error.log;
}
```

### 2. Enable the Site Configuration

Create a symbolic link to enable the site:

```bash
sudo ln -sf /etc/nginx/sites-available/hwosecurity.org.conf /etc/nginx/sites-enabled/
```

### 3. Update Main NGINX Configuration

Edit the main NGINX configuration to include site-specific configurations:

```bash
sudo nano /etc/nginx/nginx.conf
```

Add the following line inside the `http` block if it doesn't already exist:

```nginx
include /etc/nginx/sites-enabled/*.conf;
```

### 4. Test and Reload NGINX Configuration

```bash
sudo nginx -t
sudo systemctl reload nginx
```

## Setting Up SSL with Let's Encrypt

For secure HTTPS connections, you can use Let's Encrypt to obtain free SSL certificates:

1. Install Certbot:
   ```bash
   sudo apt-get update
   sudo apt-get install certbot python3-certbot-nginx
   ```

2. Obtain certificates:
   ```bash
   sudo certbot --nginx -d hwosecurity.org -d www.hwosecurity.org
   ```

3. Follow the prompts to complete the certificate installation

4. If you chose not to automatically configure NGINX, edit the site configuration to uncomment the SSL lines:
   ```bash
   sudo nano /etc/nginx/sites-available/hwosecurity.org.conf
   ```

5. Uncomment the SSL configuration lines and reload NGINX:
   ```bash
   sudo systemctl reload nginx
   ```

## Using Your Domain for Streaming

After setting up your domain, you can use the following URLs for streaming:

1. **RTMP Publishing URL** (from OBS or FFmpeg):
   ```
   rtmp://hwosecurity.org/live/your-stream-key
   ```

2. **HLS Playback URL** (for browsers and players):
   ```
   https://hwosecurity.org/hls/your-stream-key.m3u8
   ```

3. **DASH Playback URL** (for browsers and players):
   ```
   https://hwosecurity.org/dash/your-stream-key.mpd
   ```

4. **Stream Statistics**:
   ```
   https://hwosecurity.org/stats
   ```

5. **Web Application**:
   ```
   https://hwosecurity.org/
   ```

## Embedding Streams

To embed an HLS stream from your domain in a webpage:

```html
<iframe 
  src="https://hwosecurity.org/embed?url=https://hwosecurity.org/hls/your-stream-key.m3u8" 
  width="240" 
  height="135" 
  frameborder="0" 
  allowfullscreen>
</iframe>
```

## Troubleshooting Domain Issues

### Domain Not Working

1. **Check DNS Records**: Ensure your domain's A record points to your server's IP address
   ```bash
   nslookup hwosecurity.org
   ```

2. **Check NGINX Configuration**:
   ```bash
   sudo nginx -t
   ```

3. **Check NGINX Logs**:
   ```bash
   sudo tail -f /var/log/nginx/hwosecurity.org-error.log
   ```

4. **Check Firewall Rules**: Make sure ports 80, 443, and 1935 are open
   ```bash
   sudo ufw status
   ```

5. **Restart NGINX**:
   ```bash
   sudo systemctl restart nginx
   ```

### NGINX Configuration Errors

#### Unknown directive "rtmp_stat" error

If you encounter this error:
```
unknown directive "rtmp_stat" in /etc/nginx/sites-enabled/hwosecurity.org.conf
```

This happens because the RTMP module is not properly configured in the main NGINX configuration. To fix it:

1. Run the update script:
   ```bash
   sudo ./update.sh
   ```

2. The script will:
   - Fix the hwosecurity.org domain configuration
   - Update the main NGINX configuration to include RTMP module support
   - Create necessary statistics files
   - Test and reload the configuration

3. If you prefer to fix it manually, modify your site's stats blocks:
   ```nginx
   # Change this:
   location /stats {
       rtmp_stat all;
       rtmp_stat_stylesheet stat.xsl;
       add_header Refresh "5; $request_uri";
   }

   # To this:
   location /stats {
       # Stats displayed using HTTP
       root /var/www/stream;
       add_header Refresh "5; $request_uri";
   }
   ```

### SSL Certificate Issues

If you're having issues with SSL certificates:

1. Check certificate status:
   ```bash
   sudo certbot certificates
   ```

2. Renew certificates if needed:
   ```bash
   sudo certbot renew --dry-run
   ```

3. Force renewal if necessary:
   ```bash
   sudo certbot renew --force-renewal
   ```

## Additional Resources

- [NGINX Documentation](https://nginx.org/en/docs/)
- [Let's Encrypt Documentation](https://letsencrypt.org/docs/)
- [Certbot Documentation](https://certbot.eff.org/docs/)