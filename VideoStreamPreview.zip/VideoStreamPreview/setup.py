#!/usr/bin/env python3
"""
RTMP Stream Viewer - Setup Script
This script installs the RTMP Stream Viewer as a Python package
"""

from setuptools import setup, find_packages

setup(
    name="streamviewer",
    version="1.0.0",
    description="RTMP, HLS, and DASH Stream Viewer",
    author="Replit Developer",
    author_email="dev@example.com",
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        'flask>=2.3.0',
        'flask-cors>=4.0.0',
        'gunicorn>=23.0.0',
        'werkzeug>=2.3.0',
        'Jinja2>=3.1.2',
        'itsdangerous>=2.1.2',
        'click>=8.1.7',
        'requests>=2.31.0',
        'python-dotenv>=1.0.0',
        'watchdog>=3.0.0',
    ],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Web Environment',
        'Framework :: Flask',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
        'Topic :: Multimedia :: Video',
    ],
)