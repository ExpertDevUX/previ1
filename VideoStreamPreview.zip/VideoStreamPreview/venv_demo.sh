#!/bin/bash

# RTMP Stream Viewer - Virtual Environment Demo
# This script demonstrates how to set up and run the application in a virtual environment

# Exit on error
set -e

echo "RTMP Stream Viewer - Virtual Environment Demo"
echo "==============================================="

# Create a project directory to simulate installing outside of the current directory
DEMO_DIR="venv_demo_project"
if [ -d "$DEMO_DIR" ]; then
    echo "Demo directory already exists. Removing..."
    rm -rf "$DEMO_DIR"
fi

# Create the demo directory
echo "Creating demo directory..."
mkdir -p "$DEMO_DIR"
cd "$DEMO_DIR"

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install required packages
echo "Installing required packages..."
pip install Flask==2.3.3 flask-cors==4.0.0 gunicorn==23.0.0

# Create a basic project structure
echo "Creating project structure..."
mkdir -p templates static streamviewer

# Copy necessary files from parent directory
echo "Copying files..."
cp -r ../templates/* templates/
cp -r ../static/* static/
cp ../streamviewer/__init__.py streamviewer/
cp ../wsgi.py .
cp ../run.py .
cp ../start_dev.sh .
cp ../start_prod.sh .

# Make scripts executable
chmod +x start_dev.sh start_prod.sh

# Create a simple demo page
echo "Creating demo index page..."
cat > templates/demo.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>RTMP Stream Viewer Demo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .success {
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>RTMP Stream Viewer Demo</h1>
    <p class="success">Virtual environment setup successful!</p>
    <p>The application is now running in a virtual environment.</p>
    <p>You can access the main application at: <a href="/">Stream Viewer</a></p>
</body>
</html>
EOF

# Create a demo controller
echo "Creating demo controller..."
cat > streamviewer/demo.py << 'EOF'
from flask import Blueprint, render_template

demo_bp = Blueprint('demo', __name__)

@demo_bp.route('/demo')
def demo_page():
    """Render the demo page."""
    return render_template('demo.html')
EOF

# Modify the initialization file to include the demo blueprint
echo "Updating the app initialization..."
cat >> streamviewer/__init__.py << 'EOF'

# Import and register demo blueprint
try:
    from streamviewer.demo import demo_bp
    def register_demo(app):
        app.register_blueprint(demo_bp)
except ImportError:
    def register_demo(app):
        pass

# Update create_app function to register demo blueprint
original_create_app = create_app
def create_app_with_demo(config=None):
    app = original_create_app(config)
    register_demo(app)
    return app

# Replace the original create_app with our enhanced version
create_app = create_app_with_demo
EOF

# Start the application
echo "Starting the application..."
python run.py --port 5001 --debug

# Note: We won't automatically deactivate the virtual environment
# so that the user can continue to explore the demo
echo "Demo complete. To exit the virtual environment, type 'deactivate'"