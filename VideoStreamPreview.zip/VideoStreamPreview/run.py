#!/usr/bin/env python3
"""
Run script for RTMP Stream Viewer
This script starts the application using either Flask development server
or Gunicorn for production use.
"""

import os
import sys
import logging
import argparse
from streamviewer import create_app

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Run the RTMP Stream Viewer application')
    parser.add_argument('--host', default=os.environ.get('HOST', '0.0.0.0'),
                        help='Host to bind to (default: 0.0.0.0)')
    parser.add_argument('--port', type=int, default=int(os.environ.get('PORT', 5000)),
                        help='Port to bind to (default: 5000)')
    parser.add_argument('--debug', action='store_true',
                        help='Run in debug mode')
    return parser.parse_args()

if __name__ == '__main__':
    # Parse command line arguments
    args = parse_arguments()
    
    # Check if we're in debug/development mode from env or args
    debug_mode = os.environ.get('FLASK_ENV') == 'development' or args.debug
    
    # Create the Flask application instance
    app = create_app({
        'DEBUG': debug_mode
    })
    
    logger.info(f"Starting application on {args.host}:{args.port} (Debug: {debug_mode})")
    
    # Run the application
    app.run(host=args.host, port=args.port, debug=debug_mode)