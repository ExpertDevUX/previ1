#!/bin/bash

# hwosecurity.org Configuration Script
# This script configures NGINX for hwosecurity.org domain

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    print_message "This script must be run as root. Try using sudo." "$red"
    exit 1
fi

# Domain name
DOMAIN="hwosecurity.org"

print_message "hwosecurity.org Configuration" "$blue"
print_message "============================" "$blue"
echo ""

# Check if NGINX is installed
if ! command -v nginx &> /dev/null; then
    print_message "NGINX is not installed. Installing NGINX with RTMP module..." "$yellow"
    
    # Check if install_nginx_rtmp.sh exists
    if [ -f "install_nginx_rtmp.sh" ]; then
        chmod +x install_nginx_rtmp.sh
        ./install_nginx_rtmp.sh
    else
        print_message "Error: install_nginx_rtmp.sh script not found!" "$red"
        exit 1
    fi
fi

# Create directory structure if it doesn't exist
print_message "Creating stream directories..." "$green"
mkdir -p /var/www/stream/hls
mkdir -p /var/www/stream/dash
chmod 755 -R /var/www/stream
chown -R www-data:www-data /var/www/stream

# Create NGINX site configuration
print_message "Creating NGINX site configuration for $DOMAIN..." "$green"

# Check if hwosecurity.org.conf exists
if [ -f "hwosecurity.org.conf" ]; then
    # Copy the configuration file
    cp hwosecurity.org.conf /etc/nginx/sites-available/$DOMAIN.conf
else
    print_message "Creating configuration file from template..." "$yellow"
    
    # Create the configuration file
    cat > /etc/nginx/sites-available/$DOMAIN.conf << EOF
# NGINX configuration for hwosecurity.org
# RTMP, HLS, and DASH streaming

# HTTP Server for HLS/DASH and Web UI
server {
    listen 80;
    server_name hwosecurity.org www.hwosecurity.org;
    
    # Web application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # HLS streaming location
    location /hls {
        # Serve HLS fragments
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # DASH streaming location
    location /dash {
        # Serve DASH fragments
        types {
            application/dash+xml mpd;
        }
        root /var/www/stream;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
    }
    
    # Simple stats page
    location /stats {
        # Stats displayed using HTTP
        root /var/www/stream;
        add_header Refresh "5; \$request_uri";
    }
    
    location /stat.xsl {
        root /etc/nginx/;
    }
    
    # Logging configuration
    access_log /var/log/nginx/$DOMAIN-access.log;
    error_log /var/log/nginx/$DOMAIN-error.log;
}
EOF
fi

# Create symbolic link to enable the site
if [ -d "/etc/nginx/sites-enabled" ]; then
    print_message "Enabling site configuration..." "$green"
    ln -sf /etc/nginx/sites-available/$DOMAIN.conf /etc/nginx/sites-enabled/
fi

# Check if we need to insert the include directive for sites-enabled
if ! grep -q "include /etc/nginx/sites-enabled/\*.conf;" /etc/nginx/nginx.conf; then
    print_message "Updating main NGINX configuration..." "$green"
    
    # Create a backup of the original nginx.conf
    cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup
    
    # Add the include directive for site-specific configurations
    sed -i '/http {/a \    include /etc/nginx/sites-enabled/*.conf;' /etc/nginx/nginx.conf
fi

# Create a simple stats stylesheet if it doesn't exist
if [ ! -f "/etc/nginx/stat.xsl" ]; then
    print_message "Creating statistics stylesheet..." "$green"
    
    cat > /etc/nginx/stat.xsl << 'EOF'
<?xml version="1.0" encoding="utf-8" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:template match="/">
    <html>
        <head>
            <title>RTMP Statistics for hwosecurity.org</title>
            <meta charset="utf-8" />
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                    color: #333;
                    font-size: 14px;
                }
                h1, h2, h3, h4 {
                    margin: 0;
                    padding: 0;
                    color: #333;
                }
                h1 {
                    font-size: 24px;
                    margin: 0 0 20px 0;
                }
                h2 {
                    font-size: 20px;
                    margin: 0 0 15px 0;
                }
                h3 {
                    font-size: 16px;
                    margin: 10px 0;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin: 10px 0 30px 0;
                }
                th, td {
                    text-align: left;
                    padding: 8px;
                    border: 1px solid #ddd;
                }
                th {
                    background-color: #f2f2f2;
                }
                tr:nth-child(even) {
                    background-color: #f9f9f9;
                }
                .active {
                    color: green;
                }
                .inactive {
                    color: red;
                }
                .section {
                    background-color: #fff;
                    border-radius: 5px;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
                    padding: 20px;
                    margin-bottom: 20px;
                }
            </style>
        </head>
        <body>
            <h1>RTMP Statistics for hwosecurity.org</h1>
            <div class="section">
                <h2>NGINX Version <xsl:value-of select="rtmp/nginx_version"/> (pid: <xsl:value-of select="rtmp/nginx_pid"/>)</h2>
                <p>Uptime: <xsl:value-of select="rtmp/uptime"/></p>
                <p>Accepted connections: <xsl:value-of select="rtmp/naccepted"/></p>
            </div>
            <xsl:for-each select="rtmp/server">
                <div class="section">
                    <h2>Server <xsl:value-of select="@application"/> (port: <xsl:value-of select="@port"/>)</h2>
                    <xsl:for-each select="application">
                        <div class="section">
                            <h3>Application <xsl:value-of select="@name"/></h3>
                            <table>
                                <tr>
                                    <th>Type</th>
                                    <th>Count</th>
                                </tr>
                                <tr>
                                    <td>Live Streams</td>
                                    <td><xsl:value-of select="live/nclients"/></td>
                                </tr>
                                <tr>
                                    <td>Playing Streams</td>
                                    <td><xsl:value-of select="play/nclients"/></td>
                                </tr>
                            </table>
                            
                            <xsl:if test="count(live/stream) > 0">
                            <h3>Live Streams</h3>
                            <table>
                                <tr>
                                    <th>Stream Name</th>
                                    <th>Type</th>
                                    <th>Clients</th>
                                    <th>Time</th>
                                    <th>Bitrate (kb/s)</th>
                                </tr>
                                <xsl:for-each select="live/stream">
                                <tr>
                                    <td><xsl:value-of select="@name"/></td>
                                    <td><span class="active">live</span></td>
                                    <td><xsl:value-of select="nclients"/></td>
                                    <td><xsl:value-of select="time"/></td>
                                    <td><xsl:value-of select="bw_video div 1024"/></td>
                                </tr>
                                </xsl:for-each>
                            </table>
                            </xsl:if>
                            
                            <xsl:if test="count(live/stream/client) > 0">
                            <h3>Active Clients</h3>
                            <table>
                                <tr>
                                    <th>ID</th>
                                    <th>Address</th>
                                    <th>Time</th>
                                    <th>Flash version</th>
                                    <th>Protocol</th>
                                </tr>
                                <xsl:for-each select="live/stream/client">
                                <tr>
                                    <td><xsl:value-of select="@id"/></td>
                                    <td><xsl:value-of select="address"/></td>
                                    <td><xsl:value-of select="time"/></td>
                                    <td><xsl:value-of select="flashver"/></td>
                                    <td><xsl:value-of select="protocol"/></td>
                                </tr>
                                </xsl:for-each>
                            </table>
                            </xsl:if>
                        </div>
                    </xsl:for-each>
                </div>
            </xsl:for-each>
        </body>
    </html>
</xsl:template>
</xsl:stylesheet>
EOF
fi

# Test NGINX configuration
print_message "Testing NGINX configuration..." "$green"
nginx -t

if [ $? -eq 0 ]; then
    # Reload NGINX to apply changes
    print_message "Reloading NGINX..." "$green"
    systemctl reload nginx
    
    print_message "Domain configuration completed successfully!" "$green"
    echo ""
    print_message "Your streaming URLs:" "$yellow"
    echo "RTMP: rtmp://$DOMAIN/live/stream-key"
    echo "HLS: http://$DOMAIN/hls/stream-key.m3u8"
    echo "DASH: http://$DOMAIN/dash/stream-key.mpd"
    echo ""
    print_message "Web Application:" "$yellow"
    echo "http://$DOMAIN/"
    echo ""
    print_message "Stream Statistics:" "$yellow"
    echo "http://$DOMAIN/stats"
    echo ""
    
    # SSL information
    print_message "SSL Certificate Setup:" "$yellow"
    echo "To enable HTTPS, install Certbot and run:"
    echo "  sudo apt-get update"
    echo "  sudo apt-get install certbot python3-certbot-nginx"
    echo "  sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN"
    echo ""
    print_message "Application Server:" "$yellow"
    echo "Make sure your Flask application is running on port 5000:"
    echo "  ./start_prod.sh"
    echo ""
else
    print_message "NGINX configuration test failed. Please check the errors above." "$red"
    exit 1
fi