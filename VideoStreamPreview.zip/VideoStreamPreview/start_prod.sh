#!/bin/bash

# Production startup script for RTMP Stream Viewer
# This script starts the application using Gunicorn with enhanced configuration

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        -p|--port)
            PORT="$2"
            shift
            shift
            ;;
        -h|--host)
            HOST="$2"
            shift
            shift
            ;;
        -w|--workers)
            WORKERS="$2"
            shift
            shift
            ;;
        --help)
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  -p, --port PORT      Port to listen on (default: 5000)"
            echo "  -h, --host HOST      Host to bind to (default: 0.0.0.0)"
            echo "  -w, --workers COUNT  Number of worker processes (default: auto)"
            echo "  --help               Show this help message"
            echo ""
            exit 0
            ;;
        *)
            print_message "Unknown option: $1" "$red"
            exit 1
            ;;
    esac
done

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    print_message "Activating virtual environment..." "$green"
    source venv/bin/activate
fi

# Get port from environment or default to 5000
PORT=${PORT:-5000}
HOST=${HOST:-0.0.0.0}

# Auto-determine optimal worker count if not specified
if [ -z "$WORKERS" ]; then
    CORES=$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 1)
    # Gunicorn recommends (2 x num_cores) + 1 workers
    WORKERS=$((CORES * 2 + 1))
    print_message "Auto-configuring for optimal performance with $WORKERS workers" "$yellow"
else
    WORKERS=${WORKERS:-4}
fi

# Check if port is already in use
if command -v netstat &>/dev/null; then
    if netstat -tuln | grep -q ":$PORT "; then
        print_message "Warning: Port $PORT is already in use. Application might not start correctly." "$red"
    fi
fi

# Logging configuration
LOG_DIR="logs"
mkdir -p $LOG_DIR
ACCESS_LOG="$LOG_DIR/access.log"
ERROR_LOG="$LOG_DIR/error.log"

print_message "RTMP Stream Viewer - Production Server" "$blue"
print_message "=====================================" "$blue"
echo ""
print_message "Server configuration:" "$green"
echo "Host: $HOST"
echo "Port: $PORT"
echo "Workers: $WORKERS"
echo "Access log: $ACCESS_LOG"
echo "Error log: $ERROR_LOG"
echo ""

print_message "Starting application with Gunicorn..." "$green"
gunicorn --bind ${HOST}:${PORT} \
    --workers ${WORKERS} \
    --reuse-port \
    --reload \
    --access-logfile ${ACCESS_LOG} \
    --error-logfile ${ERROR_LOG} \
    --timeout 120 \
    --capture-output \
    --log-level info \
    wsgi:app

# This code will run if Gunicorn exits
exit_code=$?
if [ $exit_code -ne 0 ]; then
    print_message "Gunicorn exited with error code: $exit_code" "$red"
    echo "Check the error log at: $ERROR_LOG"
    exit $exit_code
fi