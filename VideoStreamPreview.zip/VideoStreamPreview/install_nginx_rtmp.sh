#!/bin/bash

# NGINX RTMP Server Auto-Installer
# This script installs and configures NGINX with RTMP module for live streaming
# Supports RTMP, HLS, and DASH protocols

# Exit on error
set -e

# Text formatting
bold=$(tput bold)
normal=$(tput sgr0)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
red=$(tput setaf 1)
blue=$(tput setaf 4)

# Print colored message
print_message() {
    echo "${bold}${2}$1${normal}"
}

# Print step message
print_step() {
    echo ""
    print_message "STEP $1: $2" "$blue"
    echo ""
}

# Print error and exit
print_error_exit() {
    print_message "ERROR: $1" "$red"
    exit 1
}

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    print_error_exit "This script must be run as root. Try using sudo."
fi

# Get system information
OS=$(lsb_release -si 2>/dev/null || echo "Unknown")
ARCH=$(uname -m)

print_message "NGINX RTMP Server Auto-Installer" "$green"
print_message "=================================" "$green"
echo ""
print_message "System detected: $OS on $ARCH" "$yellow"
echo ""

# Step 1: Update system
print_step "1" "Updating system packages"
apt-get update -y || print_error_exit "Failed to update packages"
apt-get upgrade -y || print_error_exit "Failed to upgrade packages"

# Step 2: Install dependencies
print_step "2" "Installing dependencies"
apt-get install -y build-essential libpcre3-dev libssl-dev zlib1g-dev \
    wget unzip libavcodec-dev libavformat-dev libavutil-dev libswscale-dev \
    || print_error_exit "Failed to install dependencies"

# Create a working directory
WORK_DIR=$(mktemp -d)
cd "$WORK_DIR" || print_error_exit "Failed to create temp directory"

# Step 3: Download and extract NGINX and RTMP module
print_step "3" "Downloading NGINX and RTMP module"

# NGINX Version
NGINX_VERSION="1.24.0"
print_message "NGINX version: $NGINX_VERSION" "$yellow"

# Download NGINX
wget "https://nginx.org/download/nginx-$NGINX_VERSION.tar.gz" || print_error_exit "Failed to download NGINX"
tar -xf "nginx-$NGINX_VERSION.tar.gz" || print_error_exit "Failed to extract NGINX"

# Download RTMP module
git clone https://github.com/arut/nginx-rtmp-module.git || print_error_exit "Failed to clone RTMP module"

# Step 4: Compile and install NGINX with RTMP module
print_step "4" "Compiling and installing NGINX with RTMP module"
cd "nginx-$NGINX_VERSION" || print_error_exit "Failed to enter NGINX directory"

# Configure NGINX with RTMP module
./configure \
    --prefix=/usr/local/nginx \
    --sbin-path=/usr/local/sbin/nginx \
    --conf-path=/etc/nginx/nginx.conf \
    --error-log-path=/var/log/nginx/error.log \
    --pid-path=/var/run/nginx.pid \
    --lock-path=/var/lock/nginx.lock \
    --http-log-path=/var/log/nginx/access.log \
    --http-client-body-temp-path=/var/cache/nginx/client_temp \
    --http-proxy-temp-path=/var/cache/nginx/proxy_temp \
    --http-fastcgi-temp-path=/var/cache/nginx/fastcgi_temp \
    --http-uwsgi-temp-path=/var/cache/nginx/uwsgi_temp \
    --http-scgi-temp-path=/var/cache/nginx/scgi_temp \
    --with-http_ssl_module \
    --with-http_realip_module \
    --with-http_addition_module \
    --with-http_sub_module \
    --with-http_dav_module \
    --with-http_flv_module \
    --with-http_mp4_module \
    --with-http_gunzip_module \
    --with-http_gzip_static_module \
    --with-http_random_index_module \
    --with-http_secure_link_module \
    --with-http_stub_status_module \
    --with-threads \
    --with-stream \
    --with-stream_ssl_module \
    --with-file-aio \
    --with-http_v2_module \
    --add-module=../nginx-rtmp-module \
    || print_error_exit "Failed to configure NGINX"

# Compile NGINX
make -j$(nproc) || print_error_exit "Failed to compile NGINX"
make install || print_error_exit "Failed to install NGINX"

# Step 5: Create directory structure
print_step "5" "Creating directory structure"
mkdir -p /var/cache/nginx
mkdir -p /etc/nginx/sites-available
mkdir -p /etc/nginx/sites-enabled
mkdir -p /var/www/html
mkdir -p /var/www/stream
mkdir -p /var/www/stream/hls
mkdir -p /var/www/stream/dash
mkdir -p /var/www/stream/recordings

# Set appropriate permissions
chmod 755 -R /var/www/stream
chown -R www-data:www-data /var/www/stream

# Step 6: Configure NGINX
print_step "6" "Configuring NGINX"

# Create main NGINX configuration
cat > /etc/nginx/nginx.conf << 'EOF'
worker_processes auto;
rtmp_auto_push on;
events {
    worker_connections 1024;
}

# RTMP configuration
rtmp {
    server {
        listen 1935; # Standard RTMP port
        chunk_size 4000;
        
        # RTMP Application
        application live {
            live on;
            record off;
            
            # Enable HLS
            hls on;
            hls_path /var/www/stream/hls;
            hls_fragment 3;
            hls_playlist_length 60;
            
            # Enable DASH
            dash on;
            dash_path /var/www/stream/dash;
            dash_fragment 3;
            dash_playlist_length 60;
            
            # Authentication (optional)
            # on_publish http://localhost/auth;
            
            # Recording (optional)
            # record all;
            # record_path /var/www/stream/recordings;
            # record_unique on;
        }
    }
}

# HTTP configuration for accessing HLS and DASH streams
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile      on;
    keepalive_timeout  65;
    server_tokens off;
    
    # Enable CORS for better browser compatibility
    add_header Access-Control-Allow-Origin *;
    add_header Access-Control-Allow-Methods 'GET, HEAD, OPTIONS';
    
    # Compression settings
    gzip  on;
    gzip_min_length 1000;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # HTTP Server
    server {
        listen      80;
        server_name localhost;
        
        # HLS streaming location
        location /hls {
            # Serve HLS fragments
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
            root /var/www/stream;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        # DASH streaming location
        location /dash {
            # Serve DASH fragments
            types {
                application/dash+xml mpd;
            }
            root /var/www/stream;
            add_header Cache-Control no-cache;
            add_header Access-Control-Allow-Origin *;
        }
        
        # Simple stats page
        location /stats {
            rtmp_stat all;
            rtmp_stat_stylesheet stat.xsl;
            add_header Refresh "5; $request_uri";
        }
        
        location /stat.xsl {
            root /etc/nginx/;
        }
        
        # Simple status page example
        location / {
            root /var/www/html;
            index index.html;
        }
    }
}
EOF

# Create a simple status page
cat > /var/www/html/index.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NGINX RTMP Server</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            line-height: 1.6;
        }
        h1, h2 {
            color: #333;
        }
        .server-info {
            background-color: #f4f4f4;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .stream-url {
            background-color: #e9e9e9;
            padding: 10px;
            border-radius: 3px;
            font-family: monospace;
            margin: 5px 0;
        }
        .info {
            border-left: 4px solid #2196F3;
            padding-left: 15px;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <h1>NGINX RTMP Server</h1>
    <div class="server-info">
        <h2>Server Information</h2>
        <p>Status: <strong>Running</strong></p>
        <p>RTMP Port: <strong>1935</strong></p>
        <p>HTTP Port: <strong>80</strong></p>
    </div>
    
    <h2>Stream URLs</h2>
    <p>Use the following URLs to publish or play your streams:</p>
    
    <h3>Publishing (Broadcaster):</h3>
    <div class="stream-url">rtmp://your-server-ip/live/stream-key</div>
    <p class="info">Replace "your-server-ip" with your server's IP address or domain name, and "stream-key" with your desired stream name.</p>
    
    <h3>Playback (Viewers):</h3>
    <p>RTMP (legacy):</p>
    <div class="stream-url">rtmp://your-server-ip/live/stream-key</div>
    
    <p>HLS (recommended for browsers):</p>
    <div class="stream-url">http://your-server-ip/hls/stream-key.m3u8</div>
    
    <p>DASH:</p>
    <div class="stream-url">http://your-server-ip/dash/stream-key.mpd</div>
    
    <h2>Statistics</h2>
    <p>View server statistics: <a href="/stats">RTMP Statistics</a></p>
    
    <h2>Need Help?</h2>
    <p>For more information, refer to the documentation or contact support.</p>
</body>
</html>
EOF

# Create stat.xsl file for rtmp_stat
cat > /etc/nginx/stat.xsl << 'EOF'
<?xml version="1.0" encoding="utf-8" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:template match="/">
    <html>
        <head>
            <title>RTMP Statistics</title>
            <meta charset="utf-8" />
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                    color: #333;
                    font-size: 14px;
                }
                h1, h2, h3, h4 {
                    margin: 0;
                    padding: 0;
                    color: #333;
                }
                h1 {
                    font-size: 24px;
                    margin: 0 0 20px 0;
                }
                h2 {
                    font-size: 20px;
                    margin: 0 0 15px 0;
                }
                h3 {
                    font-size: 16px;
                    margin: 10px 0;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin: 10px 0 30px 0;
                }
                th, td {
                    text-align: left;
                    padding: 8px;
                    border: 1px solid #ddd;
                }
                th {
                    background-color: #f2f2f2;
                }
                tr:nth-child(even) {
                    background-color: #f9f9f9;
                }
                .active {
                    color: green;
                }
                .inactive {
                    color: red;
                }
                .section {
                    background-color: #fff;
                    border-radius: 5px;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
                    padding: 20px;
                    margin-bottom: 20px;
                }
            </style>
        </head>
        <body>
            <h1>RTMP Statistics</h1>
            <div class="section">
                <h2>NGINX Version <xsl:value-of select="rtmp/nginx_version"/> (pid: <xsl:value-of select="rtmp/nginx_pid"/>)</h2>
                <p>Uptime: <xsl:value-of select="rtmp/uptime"/></p>
                <p>Accepted connections: <xsl:value-of select="rtmp/naccepted"/></p>
            </div>
            <xsl:for-each select="rtmp/server">
                <div class="section">
                    <h2>Server <xsl:value-of select="@application"/> (port: <xsl:value-of select="@port"/>)</h2>
                    <xsl:for-each select="application">
                        <div class="section">
                            <h3>Application <xsl:value-of select="@name"/></h3>
                            <table>
                                <tr>
                                    <th>Type</th>
                                    <th>Count</th>
                                </tr>
                                <tr>
                                    <td>Live Streams</td>
                                    <td><xsl:value-of select="live/nclients"/></td>
                                </tr>
                                <tr>
                                    <td>Playing Streams</td>
                                    <td><xsl:value-of select="play/nclients"/></td>
                                </tr>
                            </table>
                            
                            <xsl:if test="count(live/stream) > 0">
                            <h3>Live Streams</h3>
                            <table>
                                <tr>
                                    <th>Stream Name</th>
                                    <th>Type</th>
                                    <th>Clients</th>
                                    <th>Time</th>
                                    <th>Bitrate (kb/s)</th>
                                </tr>
                                <xsl:for-each select="live/stream">
                                <tr>
                                    <td><xsl:value-of select="@name"/></td>
                                    <td><span class="active">live</span></td>
                                    <td><xsl:value-of select="nclients"/></td>
                                    <td><xsl:value-of select="time"/></td>
                                    <td><xsl:value-of select="bw_video div 1024"/></td>
                                </tr>
                                </xsl:for-each>
                            </table>
                            </xsl:if>
                            
                            <xsl:if test="count(play/stream) > 0">
                            <h3>VOD Streams</h3>
                            <table>
                                <tr>
                                    <th>Stream Name</th>
                                    <th>Type</th>
                                    <th>Clients</th>
                                    <th>Time</th>
                                    <th>Bitrate (kb/s)</th>
                                </tr>
                                <xsl:for-each select="play/stream">
                                <tr>
                                    <td><xsl:value-of select="@name"/></td>
                                    <td><span class="active">vod</span></td>
                                    <td><xsl:value-of select="nclients"/></td>
                                    <td><xsl:value-of select="time"/></td>
                                    <td><xsl:value-of select="bw_video div 1024"/></td>
                                </tr>
                                </xsl:for-each>
                            </table>
                            </xsl:if>
                            
                            <xsl:if test="count(live/stream/client) > 0">
                            <h3>Active Clients</h3>
                            <table>
                                <tr>
                                    <th>ID</th>
                                    <th>Address</th>
                                    <th>Time</th>
                                    <th>Flash version</th>
                                    <th>Protocol</th>
                                </tr>
                                <xsl:for-each select="live/stream/client">
                                <tr>
                                    <td><xsl:value-of select="@id"/></td>
                                    <td><xsl:value-of select="address"/></td>
                                    <td><xsl:value-of select="time"/></td>
                                    <td><xsl:value-of select="flashver"/></td>
                                    <td><xsl:value-of select="protocol"/></td>
                                </tr>
                                </xsl:for-each>
                            </table>
                            </xsl:if>
                        </div>
                    </xsl:for-each>
                </div>
            </xsl:for-each>
        </body>
    </html>
</xsl:template>
</xsl:stylesheet>
EOF

# Step 7: Create Systemd service
print_step "7" "Creating systemd service"

cat > /etc/systemd/system/nginx.service << 'EOF'
[Unit]
Description=NGINX with RTMP Server
After=network.target

[Service]
Type=forking
PIDFile=/var/run/nginx.pid
ExecStartPre=/usr/local/sbin/nginx -t
ExecStart=/usr/local/sbin/nginx
ExecReload=/usr/local/sbin/nginx -s reload
ExecStop=/usr/local/sbin/nginx -s stop
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

# Step 8: Enable and start NGINX service
print_step "8" "Starting NGINX service"
systemctl daemon-reload
systemctl enable nginx
systemctl start nginx

# Check if NGINX is running
if systemctl is-active --quiet nginx; then
    print_message "NGINX RTMP server is running!" "$green"
else
    print_error_exit "Failed to start NGINX service"
fi

# Get server IP
SERVER_IP=$(hostname -I | awk '{print $1}')

# Step 9: Final messages
print_step "9" "Installation complete"

print_message "NGINX RTMP Server has been successfully installed!" "$green"
echo ""
print_message "Server information:" "$yellow"
echo "RTMP server is running on: rtmp://$SERVER_IP:1935/live"
echo "HLS stream URL example: http://$SERVER_IP/hls/stream-name.m3u8"
echo "DASH stream URL example: http://$SERVER_IP/dash/stream-name.mpd"
echo "Statistics page: http://$SERVER_IP/stats"
echo ""

print_message "Usage examples:" "$yellow"
echo "1. To stream with OBS Studio:"
echo "   - URL: rtmp://$SERVER_IP/live"
echo "   - Stream key: your-stream-name"
echo ""
echo "2. To view HLS stream in your application:"
echo "   http://$SERVER_IP/hls/your-stream-name.m3u8"
echo ""
echo "3. To view DASH stream in your application:"
echo "   http://$SERVER_IP/dash/your-stream-name.mpd"
echo ""

print_message "Configuration files:" "$yellow"
echo "NGINX config: /etc/nginx/nginx.conf"
echo "Stream directory: /var/www/stream"
echo ""

print_message "Management commands:" "$yellow"
echo "Start NGINX: systemctl start nginx"
echo "Stop NGINX: systemctl stop nginx"
echo "Restart NGINX: systemctl restart nginx"
echo "Check status: systemctl status nginx"
echo "Test config: nginx -t"
echo ""

# Clean up
cd / || exit
rm -rf "$WORK_DIR"

print_message "Thank you for using the NGINX RTMP Server Auto-Installer!" "$green"