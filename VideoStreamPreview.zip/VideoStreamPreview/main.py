"""
RTMP Stream Viewer
Main application module to create and run the Flask application
"""

import os
from streamviewer import create_app

# Create the Flask application instance
app = create_app({
    # Configuration options can be added here
    'DEBUG': os.environ.get('FLASK_ENV') == 'development'
})

if __name__ == '__main__':
    # Run the app if this file is executed directly
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '0.0.0.0')
    debug = os.environ.get('FLASK_ENV') == 'development'
    app.run(host=host, port=port, debug=debug)
