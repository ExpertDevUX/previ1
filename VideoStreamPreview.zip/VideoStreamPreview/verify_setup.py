#!/usr/bin/env python3
"""
Verification script for RTMP Stream Viewer
This script checks if all required dependencies are installed and files are in place
"""

import os
import sys
import importlib
import platform

def check_import(module_name):
    """Check if a module can be imported."""
    try:
        importlib.import_module(module_name)
        return True
    except ImportError:
        return False

def check_file(file_path):
    """Check if a file exists."""
    return os.path.isfile(file_path)

def check_directory(dir_path):
    """Check if a directory exists."""
    return os.path.isdir(dir_path)

def main():
    """Run verification checks."""
    print("RTMP Stream Viewer - Setup Verification")
    print("=======================================")
    
    # Check Python version
    python_version = platform.python_version()
    python_ok = tuple(map(int, python_version.split('.'))) >= (3, 8)
    print(f"Python version: {python_version} {'✓' if python_ok else '✗'}")
    
    # Check required modules
    required_modules = ['flask', 'flask_cors', 'gunicorn']
    modules_ok = True
    print("\nChecking required modules:")
    for module in required_modules:
        module_ok = check_import(module)
        modules_ok = modules_ok and module_ok
        print(f"  {module}: {'✓' if module_ok else '✗'}")
    
    # Check required files
    required_files = ['main.py', 'wsgi.py', 'run.py', 'setup.sh', 'start_dev.sh', 'start_prod.sh']
    files_ok = True
    print("\nChecking required files:")
    for file in required_files:
        file_ok = check_file(file)
        files_ok = files_ok and file_ok
        print(f"  {file}: {'✓' if file_ok else '✗'}")
    
    # Check required directories
    required_dirs = ['templates', 'static', 'streamviewer']
    dirs_ok = True
    print("\nChecking required directories:")
    for dir_path in required_dirs:
        dir_ok = check_directory(dir_path)
        dirs_ok = dirs_ok and dir_ok
        print(f"  {dir_path}: {'✓' if dir_ok else '✗'}")
    
    # Check streamviewer module
    streamviewer_ok = check_import('streamviewer')
    print(f"\nStreamviewer module: {'✓' if streamviewer_ok else '✗'}")
    
    # Overall status
    all_ok = python_ok and modules_ok and files_ok and dirs_ok and streamviewer_ok
    
    print("\nOverall status:", "✓ All checks passed" if all_ok else "✗ Some checks failed")
    
    return 0 if all_ok else 1

if __name__ == '__main__':
    sys.exit(main())