"""
RTMP Stream Viewer module
A Python module for creating a stream viewer application
"""

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import logging
import os

def create_app(config=None):
    """Create and configure the Flask application"""
    # Configure logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    
    # Initialize Flask app
    app = Flask(__name__, 
                template_folder=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'templates'),
                static_folder=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static'))
    
    # Set secret key
    app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key-for-development")
    
    # Enable CORS
    CORS(app)
    
    # Apply configuration
    if config:
        app.config.update(config)
    
    # Register routes
    @app.route('/')
    def index():
        """Render the main page with stream viewer."""
        return render_template('index.html')

    @app.route('/embed')
    def embed():
        """Render the embeddable version of the stream viewer."""
        stream_url = request.args.get('url', '')
        return render_template('index.html', embed=True, stream_url=stream_url)

    @app.route('/check-stream', methods=['POST'])
    def check_stream():
        """Check if a streaming URL (RTMP, HLS, or DASH) is live and available."""
        data = request.json
        stream_url = data.get('url', '')
        
        # Determine the stream type based on URL format
        stream_type = 'unknown'
        if stream_url.startswith('rtmp://'):
            stream_type = 'rtmp'
        elif stream_url.endswith('.m3u8') or '/hls/' in stream_url:
            stream_type = 'hls'
        elif stream_url.endswith('.mpd') or '/dash/' in stream_url:
            stream_type = 'dash'
        
        # In a real implementation, you would check if the stream is available
        # by making an appropriate request based on the stream type
        
        # For this example, we'll assume it's available if a URL is provided
        is_available = bool(stream_url)
        
        logger.debug(f"Stream check: {stream_url} - Type: {stream_type} - Available: {is_available}")
        
        return jsonify({
            'status': 'online' if is_available else 'offline',
            'url': stream_url,
            'type': stream_type
        })
        
    return app